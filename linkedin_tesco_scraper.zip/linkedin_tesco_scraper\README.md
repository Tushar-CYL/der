# LinkedIn Tesco Scraper — code + data

Scrapes LinkedIn People search results for Tesco managers / senior managers /
directors / partners, then opens each profile and collects the About text,
full Experience history and recent posts.

Everything is stored next to `linkedin_win.py`, so this folder is portable —
unzip it anywhere and run.

---

## 1. What's in this zip

| Path | What it is |
|---|---|
| `linkedin_win.py` | The scraper. Windows/macOS/Linux, runs a real Chrome window. |
| `linkedin_tesco_scraper.ipynb` | Same engine as a Google Colab notebook (runs headless via Xvfb). |
| `linkedin_out/people.csv` | One row per person — name, headline, location, profile URL, About. |
| `linkedin_out/experience.csv` | One row per job — title, company, dates, location, description. |
| `linkedin_out/posts.csv` | One row per post — text, timestamp, reactions, comments. |
| `linkedin_out/all_data_full_text.csv` | One row per person with the complete raw page text in a single cell. |
| `linkedin_out/linkedin_tesco.xlsx` | All of the above as one workbook, four sheets. |
| `linkedin_out/profiles.jsonl` | Raw collected record per person. **This is the resume file.** |
| `linkedin_out/people_index.json` | The 368 people found by search, scraped or not. |
| `linkedin_out/text/*.txt` | Archived page text per person — lets you re-parse offline. |

### Data currently in here

- **368** people indexed from search (collection phase is finished)
- **72** people fully scraped → **544** experience rows, **657** posts
- **296** people still to scrape

---

## 2. What to install

**Google Chrome** — the normal desktop browser. Nothing else browser-side;
Selenium Manager downloads the matching chromedriver automatically on first run.

**Python 3.9 or newer**, then:

```
pip install selenium beautifulsoup4 lxml openpyxl
```

That's the whole list. `pandas` is deliberately not used — the CSV and XLSX
writing is done with the standard-library `csv` module plus `openpyxl`.

Tested on Python 3.14.7 with Selenium 4.51.0.

---

## 3. How to run

### Step 1 — sign in (once per machine)

```
python linkedin_win.py login
```

A Chrome window opens on the LinkedIn login page. Type your email and
password yourself; if LinkedIn asks for an email/SMS verification code, enter
it. Once you reach the feed the script prints `Signed in` and saves the
session to `.chrome_linkedin_profile\` next to the script. You will not need
to log in again on this machine.

`--wait 20` gives you 20 minutes instead of the default 10, if the
verification code is slow.

### Step 2 — scrape

```
python linkedin_win.py scrape
```

It resumes automatically: anyone already in `profiles.jsonl` is skipped, so
re-running after a stop costs nothing. Progress is written after **every**
person, so an interruption never loses more than the one profile in flight.

Useful flags:

```
python linkedin_win.py scrape --limit 50      # only 50 profiles this run
python linkedin_win.py scrape --pages 10      # search pages per query
python linkedin_win.py scrape --headless      # no visible window
```

**On a machine with 16 GB RAM or more**, just run `scrape --limit 500` and let
it finish the remaining 296 in one go — roughly 2.5-3 hours.

**On 8 GB or less**, run it in batches of 50. Each invocation starts a fresh
Chrome and quits it at the end, so memory resets to zero between batches:

```
python linkedin_win.py scrape --limit 50
```

Six of those finishes the set.

### Step 3 — export

```
python linkedin_win.py export
```

Rewrites all the CSVs and the XLSX from whatever has been collected so far.
Safe to run at any point, including mid-scrape.

### Step 4 (optional) — re-parse without the network

```
python linkedin_win.py reparse
```

Rebuilds every structured field from the archived `linkedin_out/text/*.txt`
files and re-exports. No browser, no LinkedIn requests. Use this if you want
to change how experience or posts are pulled apart — edit the parser, run
`reparse`, and the existing 72 profiles are re-processed in seconds.

---

## 4. Things worth knowing

**Rate limiting is the real risk, not your hardware.** 296 profiles is about
900 page loads from one account. The script already waits a random 3-7 seconds
between actions. If profiles start coming back empty, or you land on a
`/checkpoint` page, stop and wait a few hours. Nothing is lost — it resumes.

**LinkedIn's CSS class names are randomly hashed and change on every deploy**
(`l4jkxn`, `l4jlyw`, and so on). That is why this scraper does not use CSS
selectors or XPaths for the profile content. It parses from the page's visible
**text**, anchored on stable landmarks — date lines like `Jan 2019 - Present`
for jobs, the `Feed post` heading for posts. Search result cards are found
structurally: an `/in/` link that has no `/in/` link above it in the tree.
This survives LinkedIn redesigns; selector-based scrapers break within days.

**A new machine means a new device to LinkedIn.** Expect a verification code
on the first `login`. Don't copy `.chrome_linkedin_profile\` between machines
— it is 450 MB and the session usually won't carry anyway.

**This logs in as you and reads what your account can see.** Keep the output
to yourself; it is personal data about real people, and bulk collection is
against LinkedIn's User Agreement regardless of what your account can access.
