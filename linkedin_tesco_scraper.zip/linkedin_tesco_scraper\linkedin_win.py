"""Windows runner for the LinkedIn people scrape.

Two phases, because logging in needs you at the keyboard:

    python linkedin_win.py login      # opens Chrome, waits for you to sign in
    python linkedin_win.py scrape     # reuses that session, collects the data
    python linkedin_win.py export     # writes csv/xlsx from what was collected

The Chrome profile lives in .chrome_linkedin_profile next to this file, so the
session survives between runs and you only sign in once.
"""

import argparse
import csv
import json
import os
import random
import re
import sys
import time
import traceback
from urllib.parse import quote_plus

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.common.exceptions import (NoSuchElementException, TimeoutException,
                                        WebDriverException)
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# ---------------------------------------------------------------- config

SEARCH_QUERIES = [
    "Tesco manager",
    "Tesco senior manager",
    "Tesco director",
    "Tesco partner",
]

PAGES_PER_QUERY = 10
MAX_PROFILES = 200

CURRENT_COMPANY_ID = None     # e.g. "2648" to pin to the real Tesco company page

SCRAPE_ABOUT = True
SCRAPE_EXPERIENCE = True
SCRAPE_POSTS = True
POSTS_SCROLLS = 3

MIN_DELAY, MAX_DELAY = 3.0, 7.0
PAGE_TIMEOUT = 30

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "linkedin_out")
TEXT_DIR = os.path.join(OUT_DIR, "text")
PROFILE_DIR = os.path.join(HERE, ".chrome_linkedin_profile")

JSONL = os.path.join(OUT_DIR, "profiles.jsonl")
INDEX_JSON = os.path.join(OUT_DIR, "people_index.json")

driver = None

# ---------------------------------------------------------------- browser


def start_browser(headless=False):
    global driver
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(TEXT_DIR, exist_ok=True)
    os.makedirs(PROFILE_DIR, exist_ok=True)

    opts = Options()
    opts.add_argument("--user-data-dir=" + PROFILE_DIR)
    opts.add_argument("--profile-directory=Default")
    opts.add_argument("--window-size=1600,1000")
    opts.add_argument("--lang=en-GB,en")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    if headless:
        opts.add_argument("--headless=new")

    d = webdriver.Chrome(options=opts)
    d.set_page_load_timeout(PAGE_TIMEOUT)
    d.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
    })
    driver = d
    return d


def stop_browser():
    global driver
    try:
        if driver:
            driver.quit()
    except Exception:
        pass
    driver = None


# Signed-out pages carry a .global-nav too, so nav presence proves nothing. Require a
# member-only element AND a URL that is not a login/challenge page.
SIGNED_OUT_URL_RE = re.compile(r"/(login|signup|checkpoint|authwall|uas/)", re.I)
# LinkedIn renames CSS classes constantly, so match on member-only *text* instead.
SIGNED_IN_MARKERS = ("Start a post", "Add to your feed", "Profile viewers")


def logged_in(verbose=False):
    try:
        driver.get("https://www.linkedin.com/feed/")
    except TimeoutException:
        pass
    time.sleep(3)
    url = driver.current_url
    if SIGNED_OUT_URL_RE.search(url):
        if verbose:
            print("   not signed in - sitting on %s" % url[:90])
        return False
    src = driver.page_source
    hits = [m for m in SIGNED_IN_MARKERS if m in src]
    ok = "/feed" in url and bool(hits)
    if verbose:
        print("   url=%s | markers=%s -> %s"
              % (url[:60], hits or "none", "signed in" if ok else "NOT signed in"))
    return ok


def shot(label):
    path = os.path.join(TEXT_DIR, re.sub(r"[^A-Za-z0-9_.-]", "_", label) + ".png")
    try:
        driver.save_screenshot(path)
        print("   screenshot -> " + path)
    except Exception:
        pass

# ---------------------------------------------------------------- helpers

XPATHS = {
    "search_box":    "/html/body/div[1]/div[1]/div[2]/div[1]/header/div/div/div/div[2]/div[2]/div/input",
    "people_filter": "/html/body/div[1]/div[1]/div[2]/div[2]/div/div/div/div/div/div/div[1]/div/div",
    "about_section": "/html/body/div[1]/div[1]/div[2]/div[2]/div/main/div/div/section/div/div/div[1]/div/section/div/div/div[2]/div[1]",
}


def human_pause():
    time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))


def goto(url, wait_css=None, timeout=20):
    human_pause()
    try:
        driver.get(url)
    except TimeoutException:
        pass
    if wait_css:
        try:
            WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, wait_css)))
        except TimeoutException:
            pass
    else:
        time.sleep(2)
    return driver.page_source


def scroll_page(times=4, pause=1.4):
    last = 0
    for _ in range(times):
        driver.execute_script("window.scrollBy(0, document.body.scrollHeight*0.8);")
        time.sleep(pause)
        h = driver.execute_script("return document.body.scrollHeight")
        if h == last:
            break
        last = h
    driver.execute_script("window.scrollTo(0, 0);")


def expand_show_more():
    sels = ["button.inline-show-more-text__button",
            "button[aria-label*='see more']",
            "button[aria-label*='Show more']"]
    for sel in sels:
        for b in driver.find_elements(By.CSS_SELECTOR, sel)[:25]:
            try:
                driver.execute_script("arguments[0].click();", b)
                time.sleep(0.25)
            except WebDriverException:
                pass


def visible_texts(node, limit=12):
    seen, out = set(), []
    for s in node.select('span[aria-hidden="true"]'):
        t = s.get_text(" ", strip=True)
        if t and t not in seen:
            seen.add(t)
            out.append(t)
        if len(out) >= limit:
            break
    return out


def page_text():
    # visible text of the page, which is what we archive instead of raw HTML
    soup = BeautifulSoup(driver.page_source, "lxml")
    for junk in soup(["script", "style", "noscript"]):
        junk.decompose()
    main = soup.find("main") or soup
    return re.sub(r"\n{3,}", "\n\n", main.get_text("\n", strip=True))


def dump_text(tag, text=None):
    tag = re.sub(r"[^A-Za-z0-9_.-]", "_", tag)[:80]
    path = os.path.join(TEXT_DIR, tag + ".txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text if text is not None else page_text())
    return path


def slug_of(url):
    m = re.search(r"/in/([^/?#]+)", url or "")
    return m.group(1) if m else ""

# ---------------------------------------------------------------- search

JUNK_NAMES = {"", "linkedin member", "status is offline", "status is reachable"}
SKIP_TEXT_RE = re.compile(r"^(Connect|Follow|Message|View|Save|\d+(st|nd|rd)$)")


def search_url(query, page=1):
    url = "https://www.linkedin.com/search/results/people/?keywords=" + quote_plus(query)
    if CURRENT_COMPANY_ID:
        url += '&currentCompany=%5B"' + str(CURRENT_COMPANY_ID) + '"%5D'
    if page > 1:
        url += "&page=" + str(page)
    return url


IN_RE = re.compile(r"/in/")
# trailing connection degree on the name line, e.g. "Jane Doe · 2nd"
DEGREE_RE = re.compile(r"[·•∙|]\s*(1st|2nd|3rd\+?|Following|Connect)\s*$", re.I)


def parse_search_results(html):
    # LinkedIn ships hashed CSS classes (l4jkxn, ...) that change every deploy, so match on
    # structure: a result card is an /in/ anchor with no /in/ anchor above it. Mutual-connection
    # links are always nested inside a card anchor, which is what excludes them.
    soup = BeautifulSoup(html, "lxml")
    main = soup.find("main") or soup
    people, seen = [], set()

    for a in main.select('a[href*="/in/"]'):
        if a.find_parent("a", href=IN_RE):
            continue
        slug = slug_of(a.get("href", ""))
        if not slug or slug in seen:
            continue

        blocks = []
        for p in a.find_all("p"):
            t = re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
            if t and t not in blocks:
                blocks.append(t)
        if not blocks:
            continue

        name = DEGREE_RE.sub("", blocks[0]).strip(" ·•|")
        if len(name) < 2 or name.lower() in JUNK_NAMES:
            continue

        rest = blocks[1:]
        mutual = next((t for t in rest if "mutual connection" in t.lower()), "")
        rest = [t for t in rest if t != mutual]
        # LinkedIn's AI blurb is an extra long paragraph after headline + location
        summary = ""
        if len(rest) > 2:
            summary = max(rest[2:], key=len)
            rest = rest[:2]

        seen.add(slug)
        people.append({
            "slug": slug,
            "name": name,
            "headline": rest[0] if rest else "",
            "location": rest[1] if len(rest) > 1 else "",
            "ai_summary": summary,
            "mutual_connections": mutual,
            "profile_url": "https://www.linkedin.com/in/" + slug + "/",
        })
    return people


def collect_people(queries=None, pages=None):
    queries = queries if queries is not None else SEARCH_QUERIES
    pages = pages if pages is not None else PAGES_PER_QUERY
    found = {}

    if os.path.exists(INDEX_JSON):
        with open(INDEX_JSON, encoding="utf-8") as f:
            for r in json.load(f):
                found[r["slug"]] = r
        print("%d people already in the index" % len(found))

    for q in queries:
        print("\n=== %s ===" % q)
        for page in range(1, pages + 1):
            goto(search_url(q, page), wait_css="main")
            scroll_page(times=3, pause=1.0)

            if "/search/results/people" not in driver.current_url:
                print("  page %2d: redirected to %s - rate-limited or signed out. Stopping query."
                      % (page, driver.current_url))
                dump_text("search_redirect_%s_%d" % (q, page))
                shot("search_redirect_%s_%d" % (q, page))
                break

            rows = parse_search_results(driver.page_source)
            new = 0
            for r in rows:
                if r["slug"] not in found:
                    r["found_via"] = q
                    found[r["slug"]] = r
                    new += 1
            print("  page %2d: %2d results (%2d new, %3d total)" % (page, len(rows), new, len(found)))

            if not rows:
                dump_text("search_empty_%s_%d" % (q, page))
                print("  nothing parsed - end of results, or selectors need a look.")
                break

    with open(INDEX_JSON, "w", encoding="utf-8") as f:
        json.dump(list(found.values()), f, indent=2, ensure_ascii=False)
    print("\n%d unique people -> %s" % (len(found), INDEX_JSON))
    return list(found.values())

# ---------------------------------------------------------------- profile

DATE_RE = re.compile(r"\b(19|20)\d{2}\b|\bPresent\b", re.I)


# throwaway fragments in the profile header: degree badges, counters, action buttons
JUNK_P_RE = re.compile(
    r"^(\W*(1st|2nd|3rd\+?)\W*|Contact info|connections?|followers?|[\d,]+\+?|"
    r"Message|Connect|Follow|More|\W+)$", re.I)


def scrape_top_card(soup):
    # the profile name is an <h2>; these pages carry no <h1> at all
    main = soup.find("main") or soup
    out = {"name_profile": "", "headline_profile": "", "location_profile": ""}

    h2 = main.find("h2")
    if h2:
        out["name_profile"] = h2.get_text(" ", strip=True)

    raw = p_blocks(main)[:16]
    clean = [t for t in raw if not JUNK_P_RE.match(t)]
    if clean:
        out["headline_profile"] = clean[0]
    if "Contact info" in raw:
        before = [t for t in raw[:raw.index("Contact info")] if not JUNK_P_RE.match(t)]
        if len(before) >= 2:
            out["location_profile"] = before[-1]
    elif len(clean) > 2:
        out["location_profile"] = clean[2]
    return out


def scrape_about(soup):
    main = soup.find("main") or soup
    for h in main.find_all(["h2", "h3"]):
        if h.get_text(strip=True).lower() == "about":
            sec = h.find_parent("section") or h.parent
            blocks = [t for t in p_blocks(sec) if t.lower() != "about"]
            if blocks:
                return max(blocks, key=len)
    return ""


def p_blocks(node):
    out = []
    for p in node.find_all("p"):
        t = re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
        if t and t not in out:
            out.append(t)
    return out


EMP_TYPE_RE = re.compile(
    r"\b(Full-time|Part-time|Contract|Internship|Freelance|Self-employed|Seasonal|"
    r"Apprenticeship|Permanent|Temporary)\b", re.I)
DATE_LINE_RE = re.compile(
    r"^((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?(19|20)\d{2}\s*[-–]\s*"
    r"((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?((19|20)\d{2}|Present)", re.I)
MIDDOT = "·"
# second line of a company group header: "Full-time <middot> 6 yrs 5 mos", or just "4 yrs"
DURATION_RE = re.compile(
    r"^(?:(?:Full-time|Part-time|Contract|Internship|Freelance|Self-employed|Seasonal|"
    r"Apprenticeship|Permanent|Temporary)\s*[·-]?\s*)?\d+\s*(?:yr|yrs|mo|mos)\b", re.I)
NOISE_RE = re.compile(r"^(Ad Options|Why am I seeing this ad|Don.t want to see this|"
                      r"Experience|More profiles|People you may know|Show all)", re.I)


def parse_experience_text(text):
    # Parsed from page TEXT, not the DOM, so LinkedIn's hashed CSS classes cannot break it.
    # Every role is anchored on its date line; three layouts occur around it:
    #   A grouped    "Tesco" / "Full-time <middot> 6 yrs" ... Title / Dates / Location
    #   B ungrouped  Title / "Company <middot> Full-time" / Dates / Location
    #   C bare       Title / "Company" / Dates / Location
    lines = [l.strip() for l in (text or "").split("\n") if l.strip()]
    date_idx = [i for i, l in enumerate(lines) if DATE_LINE_RE.match(l)]
    rows, group = [], ""

    for i, line in enumerate(lines):
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        # layout A header: a company name whose next line is an employment type or a duration
        if (nxt and (EMP_TYPE_RE.match(nxt) or DURATION_RE.match(nxt))
                and not DATE_LINE_RE.match(nxt)
                and not DATE_LINE_RE.match(line) and not NOISE_RE.match(line)):
            group = line
            continue

        if not DATE_LINE_RE.match(line):
            continue

        prev = lines[i - 1] if i >= 1 else ""
        prev2 = lines[i - 2] if i >= 2 else ""

        if MIDDOT in prev and EMP_TYPE_RE.search(prev) and not EMP_TYPE_RE.match(prev):
            company, title = prev.split(MIDDOT)[0].strip(), prev2   # layout B
            group = ""
        elif group:
            company, title = group, prev                            # layout A
        else:
            company, title = prev, prev2                            # layout C

        nxt_date = next((d for d in date_idx if d > i), len(lines))
        tail = [t for t in lines[i + 1:max(i + 1, nxt_date - 1)] if not NOISE_RE.match(t)]
        location = ""
        if tail and not DATE_LINE_RE.match(tail[0]) and len(tail[0]) <= 90:
            location = tail[0]
            tail = tail[1:]

        title = title.strip()
        if not title or NOISE_RE.match(title) or title == company:
            continue
        rows.append({
            "title": title,
            "company": company.strip(),
            "dates": line,
            "location": location,
            "description": " ".join(t for t in tail if t not in (company, title)).strip(),
            "raw": " | ".join(lines[max(0, i - 2):i + 2]),
        })
    return rows


def parse_experience(html):
    # Roles live in <li> blocks holding <p> runs: title / dates / location / description.
    # The employer is on a /company/ anchor OUTSIDE the <li> (a group header), and each role
    # <li> links to that same /company/ href - which is how a role is tied to its company.
    soup = BeautifulSoup(html, "lxml")
    main = soup.find("main") or soup

    companies = {}
    for a in main.select('a[href*="/company/"]'):
        if a.find_parent("li"):
            continue
        ps = p_blocks(a)
        if ps:
            companies.setdefault(a.get("href", "").split("?")[0], ps[0])

    rows = []
    for li in main.find_all("li"):
        if li.find("li"):
            continue
        blocks = p_blocks(li)
        if len(blocks) < 2:
            continue
        dates = next((t for t in blocks[1:] if DATE_RE.search(t)), "")
        if not dates:
            continue          # ads and "More profiles for you" carry no date range

        title = blocks[0]
        ca = li.select_one('a[href*="/company/"]')
        company = companies.get(ca.get("href", "").split("?")[0], "") if ca else ""

        rest = [t for t in blocks[1:] if t != dates]
        if not company and rest:
            company = rest.pop(0)        # ungrouped role: employer follows the title

        desc = max([t for t in rest if len(t) > 120], key=len, default="")
        location = next((t for t in rest if t != desc and len(t) <= 120), "")

        rows.append({
            "title": title,
            "company": company,
            "dates": dates,
            "location": location,
            "description": desc,
            "raw": " | ".join(blocks[:8]),
        })
    return rows


def scrape_experience(slug):
    goto("https://www.linkedin.com/in/" + slug + "/details/experience/", wait_css="main")
    scroll_page(times=3, pause=1.0)
    expand_show_more()
    txt = page_text()
    rows = parse_experience_text(txt)
    if not rows:
        rows = parse_experience(driver.page_source)
    return rows, txt


POST_DATE_RE = re.compile(
    r"^((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s*\d{4}"
    r"|\d+\s*(m|h|d|w|mo|yr)s?)\b", re.I)


def parse_posts(html):
    # Each activity item is announced by an <h2>Feed post</h2>; the enclosing div holds
    # <p> runs: author / degree / author headline / date / post text. No urn attributes exist.
    soup = BeautifulSoup(html, "lxml")
    main = soup.find("main") or soup
    out, seen = [], set()

    for h in main.find_all(["h2", "h3"]):
        label = h.get_text(strip=True).lower()
        if "feed post" not in label and "post" != label:
            continue

        card, blocks = h.parent, []
        for _ in range(4):
            if card is None:
                break
            blocks = p_blocks(card)
            if blocks:
                break
            card = card.parent
        if len(blocks) < 2:
            continue

        author = blocks[0]
        idx = next((i for i, t in enumerate(blocks) if POST_DATE_RE.match(t)), None)
        if idx is None:
            continue          # no timestamp => page furniture, not an actual post
        posted = blocks[idx]
        after = blocks[idx + 1:]
        after = [t for t in after if not JUNK_P_RE.match(t) and t != author]
        if not after:
            continue
        text = after[0] if len(after[0]) > 40 else max(after, key=len)

        key = text[:120]
        if key in seen:
            continue
        seen.add(key)
        out.append({
            "author": author,
            "posted": posted,
            "text": text,
            "engagement": "",
            "url": "",
        })
    return out


def scrape_posts(slug):
    goto("https://www.linkedin.com/in/" + slug + "/recent-activity/all/", wait_css="main")
    scroll_page(times=POSTS_SCROLLS, pause=1.8)
    expand_show_more()
    return parse_posts(driver.page_source), page_text()


def scrape_profile(person):
    slug = person["slug"]
    rec = dict(person)

    goto(person["profile_url"], wait_css="main")
    if "/in/" not in driver.current_url:
        rec["error"] = "redirected to " + driver.current_url
        return rec

    scroll_page(times=3, pause=1.2)
    expand_show_more()
    soup = BeautifulSoup(driver.page_source, "lxml")
    profile_txt = page_text()

    rec.update(scrape_top_card(soup))
    rec["about"] = scrape_about(soup) if SCRAPE_ABOUT else ""
    rec["experience"], exp_txt = scrape_experience(slug) if SCRAPE_EXPERIENCE else ([], "")
    rec["posts"], posts_txt = scrape_posts(slug) if SCRAPE_POSTS else ([], "")

    # archive the full visible text of all three pages, as text
    full = ("===== PROFILE =====\n" + profile_txt
            + "\n\n===== EXPERIENCE =====\n" + exp_txt
            + "\n\n===== ACTIVITY =====\n" + posts_txt)
    rec["text_file"] = dump_text(slug, full)
    rec["profile_text"] = profile_txt
    rec["experience_text"] = exp_txt
    rec["activity_text"] = posts_txt

    exp = rec["experience"]
    rec["current_title"] = exp[0]["title"] if exp else rec.get("headline_profile", "")
    rec["current_company"] = exp[0]["company"] if exp else ""
    rec["n_experience"] = len(exp)
    rec["n_posts"] = len(rec["posts"])
    return rec

# ---------------------------------------------------------------- run


def already_done():
    done = set()
    if os.path.exists(JSONL):
        with open(JSONL, encoding="utf-8") as f:
            for line in f:
                try:
                    done.add(json.loads(line)["slug"])
                except Exception:
                    pass
    return done


def run_profiles(index, limit=None):
    limit = limit if limit is not None else MAX_PROFILES
    done = already_done()
    todo = [p for p in index if p["slug"] not in done]
    if limit:
        todo = todo[:limit]

    print("\n%d already scraped | %d to go\n" % (len(done), len(todo)))
    fails = 0

    with open(JSONL, "a", encoding="utf-8") as out:
        for i, person in enumerate(todo, 1):
            label = "[%3d/%3d] %-38s" % (i, len(todo), person["name"][:38])
            try:
                rec = scrape_profile(person)
                out.write(json.dumps(rec, ensure_ascii=False) + "\n")
                out.flush()
                print("%s exp=%-2d posts=%d"
                      % (label, rec.get("n_experience", 0), rec.get("n_posts", 0)))
                fails = 0
            except KeyboardInterrupt:
                print("\nStopped. Progress is saved.")
                break
            except Exception as e:
                fails += 1
                print("%s FAILED: %s: %s" % (label, type(e).__name__, e))
                traceback.print_exc(limit=1)
                if fails >= 5:
                    print("\n5 failures in a row - stopping. Usually signed out or rate-limited.")
                    shot("run_failure")
                    break
                time.sleep(30)

    print("\nSaved to " + JSONL)

# ---------------------------------------------------------------- export


def export():
    records = []
    if os.path.exists(JSONL):
        with open(JSONL, encoding="utf-8") as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    print("%d profiles loaded" % len(records))
    if not records:
        print("Nothing to export yet - run the scrape first.")
        return

    people_cols = ["slug", "name", "headline", "location", "name_profile", "headline_profile",
                   "location_profile", "current_title", "current_company", "about", "ai_summary",
                   "mutual_connections", "n_experience", "n_posts", "found_via", "profile_url",
                   "text_file", "error"]
    people_rows = [[r.get(c, "") for c in people_cols] for r in records]

    # everything, including the full page text, in one wide file
    full_cols = people_cols + ["profile_text", "experience_text", "activity_text"]
    full_rows = [[r.get(c, "") for c in full_cols] for r in records]

    exp_cols = ["slug", "name", "order", "title", "company", "dates", "location", "description"]
    exp_rows = [[r["slug"], r.get("name", ""), i, e.get("title", ""), e.get("company", ""),
                 e.get("dates", ""), e.get("location", ""), e.get("description", "")]
                for r in records for i, e in enumerate(r.get("experience") or [], 1)]

    post_cols = ["slug", "name", "author", "posted", "text", "engagement", "url"]
    post_rows = [[r["slug"], r.get("name", ""), p.get("author", ""), p.get("posted", ""),
                  p.get("text", ""), p.get("engagement", ""), p.get("url", "")]
                 for r in records for p in (r.get("posts") or [])]

    tables = [("people", people_cols, people_rows),
              ("experience", exp_cols, exp_rows),
              ("posts", post_cols, post_rows),
              ("all_data_full_text", full_cols, full_rows)]

    for name, cols, rows in tables:
        path = os.path.join(OUT_DIR, name + ".csv")
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(cols)
            w.writerows(rows)
        print("%-11s %5d rows -> %s" % (name, len(rows), path))

    try:
        from openpyxl import Workbook
        wb = Workbook()
        wb.remove(wb.active)
        for name, cols, rows in tables:
            ws = wb.create_sheet(name.capitalize())
            ws.append(cols)
            for row in rows:
                # Excel rejects control characters and caps cells at 32767 chars
                ws.append([re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v))[:32000]
                           for v in row])
        xlsx = os.path.join(OUT_DIR, "linkedin_tesco.xlsx")
        wb.save(xlsx)
        print("xlsx -> " + xlsx)
    except Exception as e:
        print("xlsx skipped (%s) - the CSVs are written" % e)

# ---------------------------------------------------------------- cli


def cmd_login(args):
    start_browser(headless=False)
    print("Chrome is open. Sign in to LinkedIn in that window.")
    print("Waiting up to %d minutes ...\n" % args.wait)
    try:
        driver.get("https://www.linkedin.com/login")
    except TimeoutException:
        pass

    deadline = time.time() + args.wait * 60
    while time.time() < deadline:
        time.sleep(5)
        try:
            url = driver.current_url
        except WebDriverException:
            print("Chrome was closed before sign-in completed.")
            return 1
        if (not SIGNED_OUT_URL_RE.search(url)
                and any(m in driver.page_source for m in SIGNED_IN_MARKERS)):
            print("Signed in. Session saved to " + PROFILE_DIR)
            print("Now run:  python linkedin_win.py scrape")
            stop_browser()
            return 0
        left = int(deadline - time.time())
        state = "challenge" if "checkpoint" in url else "signed out"
        print("  still waiting (%ds left) - %s - %s" % (left, state, url[:70]))
    print("Timed out waiting for sign-in.")
    stop_browser()
    return 1


def cmd_scrape(args):
    start_browser(headless=args.headless)
    if not logged_in():
        print("Not signed in. Run:  python linkedin_win.py login")
        shot("not_logged_in")
        stop_browser()
        return 1
    print("Session OK.")
    try:
        index = collect_people(pages=args.pages)
        if index:
            run_profiles(index, limit=args.limit)
    finally:
        stop_browser()
    export()
    return 0


def cmd_export(args):
    export()
    return 0


def cmd_reparse(args):
    # Re-derive the structured fields from the archived text, with no network access.
    # Lets a parser fix be applied to data already collected.
    if not os.path.exists(JSONL):
        print("Nothing collected yet.")
        return 1
    records = []
    with open(JSONL, encoding="utf-8") as f:
        for line in f:
            try:
                records.append(json.loads(line))
            except Exception:
                pass

    changed = 0
    for r in records:
        before = len(r.get("experience") or [])
        rows = parse_experience_text(r.get("experience_text", ""))
        if rows:
            r["experience"] = rows
            r["n_experience"] = len(rows)
            r["current_title"] = rows[0]["title"]
            r["current_company"] = rows[0]["company"]
            if len(rows) != before:
                changed += 1
    with open(JSONL, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("reparsed %d profiles (%d changed)" % (len(records), changed))
    export()
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("login", help="open Chrome and wait for you to sign in")
    p.add_argument("--wait", type=int, default=10, help="minutes to wait (default 10)")
    p.set_defaults(func=cmd_login)

    p = sub.add_parser("scrape", help="collect search results, then each profile")
    p.add_argument("--pages", type=int, default=None, help="search pages per query")
    p.add_argument("--limit", type=int, default=None, help="max profiles this run")
    p.add_argument("--headless", action="store_true", help="hide the browser window")
    p.set_defaults(func=cmd_scrape)

    p = sub.add_parser("export", help="write csv/xlsx from collected data")
    p.set_defaults(func=cmd_export)

    p = sub.add_parser("reparse", help="rebuild fields from archived text, then export")
    p.set_defaults(func=cmd_reparse)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
