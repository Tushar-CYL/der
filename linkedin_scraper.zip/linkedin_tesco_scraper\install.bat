@echo off
echo Installing Python packages...
pip install selenium beautifulsoup4 lxml openpyxl
echo.
echo Done. Next:  python linkedin_win.py login
pause
