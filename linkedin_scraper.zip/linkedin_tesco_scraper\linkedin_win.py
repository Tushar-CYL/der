"""LinkedIn people scraper: name, location, title, experience and About, per company.

Five fields per person and nothing else. Posts are not collected at all - the activity
feed cost thirty-odd requests per person and was what triggered rate limiting, so it is
gone, along with its parser.

    python linkedin_win.py login                 # sign in once, session is saved
    python linkedin_win.py scrape                # asks which company, then runs
    python linkedin_win.py scrape --company Tesco
    python linkedin_win.py export                # rebuild csv/json from collected data
    python linkedin_win.py reparse               # re-derive fields offline, then export

Data lands in linkedin_out\\<company>\\ so several companies can be kept side by side.
Everything resumes: a person already collected is never fetched twice.
"""

import argparse
import csv
import datetime as dt
import json
import os
import random
import re
import shutil
import sys
import time
import traceback
from urllib.parse import quote_plus

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# ---------------------------------------------------------------- config

ROLE_TERMS = ["manager", "senior manager", "director", "partner"]

PAGES_PER_QUERY = 10
MAX_PROFILES = 500

INDIA_ONLY = True
INDIA_GEO_URN = "102713980"   # LinkedIn's geo id for India, used as a search facet

SCRAPE_ABOUT = True
SCRAPE_EXPERIENCE = True
# Pacing. LinkedIn rate-limits on requests per session, so the budget is spent on page
# loads, not on waiting. A person now costs two loads - the profile and the experience
# page - which works out around one page view every 13 seconds including the pauses.
# That is roughly what someone reading profiles by hand does.
MIN_DELAY, MAX_DELAY = 3.0, 7.5
FAST_DELAY = (1.2, 2.6)

# A real person does not click at a fixed rate for an hour without pause. These breaks,
# and the wide random spread above, are what stop the traffic looking like a metronome.
COOLDOWN_EVERY = 30
COOLDOWN_SECS = 120
# every so often, a much longer break, as if the person walked away
LONG_BREAK_EVERY = 100
LONG_BREAK_SECS = 420
PAGE_TIMEOUT = 30

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_OUT = os.path.join(HERE, "linkedin_out")
PROFILE_DIR = os.path.join(HERE, ".chrome_linkedin_profile")

# set by set_company()
COMPANY = ""
OUT_DIR = ROOT_OUT
TEXT_DIR = os.path.join(ROOT_OUT, "text")
JSONL = os.path.join(ROOT_OUT, "profiles.jsonl")
INDEX_JSON = os.path.join(ROOT_OUT, "people_index.json")
STATE_JSON = os.path.join(ROOT_OUT, "state.json")

driver = None
TODAY = dt.date.today()


class Blocked(Exception):
    """LinkedIn bounced us to a login, authwall or security checkpoint.

    Raised instead of recorded, because continuing after a block is actively harmful: it
    writes a run of empty records, marks those people as done so a resume skips them, and
    keeps hammering an endpoint that has already said no.
    """


def company_slug(name):
    return re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_") or "company"


def set_company(name):
    """Point every path at linkedin_out\\<company>\\, creating it if needed."""
    global COMPANY, OUT_DIR, TEXT_DIR, JSONL, INDEX_JSON, STATE_JSON
    COMPANY = (name or "").strip()
    OUT_DIR = os.path.join(ROOT_OUT, company_slug(COMPANY))
    TEXT_DIR = os.path.join(OUT_DIR, "text")
    JSONL = os.path.join(OUT_DIR, "profiles.jsonl")
    INDEX_JSON = os.path.join(OUT_DIR, "people_index.json")
    STATE_JSON = os.path.join(OUT_DIR, "state.json")
    os.makedirs(TEXT_DIR, exist_ok=True)
    adopt_legacy_data()
    with open(STATE_JSON, "w", encoding="utf-8") as f:
        json.dump({"company": COMPANY, "updated": TODAY.isoformat()}, f, indent=2)


def adopt_legacy_data():
    """Earlier runs wrote straight into linkedin_out\\ with no company folder.

    Those files are Tesco data, so move them into the Tesco folder once, which keeps
    the 72 already-collected profiles and lets the scrape resume instead of restart.
    """
    legacy = os.path.join(ROOT_OUT, "profiles.jsonl")
    if company_slug(COMPANY) != "tesco" or not os.path.exists(legacy):
        return
    if os.path.exists(JSONL):
        return
    for name in ("profiles.jsonl", "people_index.json"):
        src = os.path.join(ROOT_OUT, name)
        if os.path.exists(src):
            shutil.move(src, os.path.join(OUT_DIR, name))
    src_text = os.path.join(ROOT_OUT, "text")
    if os.path.isdir(src_text):
        for fn in os.listdir(src_text):
            dst = os.path.join(TEXT_DIR, fn)
            if not os.path.exists(dst):
                shutil.move(os.path.join(src_text, fn), dst)
        try:
            os.rmdir(src_text)
        except OSError:
            pass
    print("moved earlier Tesco data into " + OUT_DIR)


def load_state():
    for path in (STATE_JSON, os.path.join(ROOT_OUT, "state.json")):
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    return {}

# ---------------------------------------------------------------- browser


def start_browser(headless=False, images=False):
    global driver
    os.makedirs(PROFILE_DIR, exist_ok=True)

    opts = Options()
    opts.add_argument("--user-data-dir=" + PROFILE_DIR)
    opts.add_argument("--profile-directory=Default")
    opts.add_argument("--window-size=1600,1000")
    opts.add_argument("--lang=en-GB,en")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    # Images are never parsed, and blocking them is the single biggest speed win - but
    # a CAPTCHA and a security-check photo are images too, so sign-in must load them or
    # the challenge is invisible and impossible to answer.
    opts.add_experimental_option("prefs", {
        "profile.managed_default_content_settings.images": 1 if images else 2,
        "profile.default_content_setting_values.notifications": 2,
    })
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    if headless:
        opts.add_argument("--headless=new")

    d = webdriver.Chrome(options=opts)
    d.set_page_load_timeout(PAGE_TIMEOUT)
    d.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
    })
    driver = d
    return d


def stop_browser():
    global driver
    try:
        if driver:
            driver.quit()
    except Exception:
        pass
    driver = None


# Signed-out pages carry a .global-nav too, so nav presence proves nothing. Require a
# member-only element AND a URL that is not a login/challenge page.
SIGNED_OUT_URL_RE = re.compile(r"/(login|signup|checkpoint|authwall|uas/)", re.I)
# LinkedIn renames CSS classes constantly, so match on member-only *text* instead.
SIGNED_IN_MARKERS = ("Start a post", "Add to your feed", "Profile viewers")


def logged_in(verbose=False):
    try:
        driver.get("https://www.linkedin.com/feed/")
    except TimeoutException:
        pass
    time.sleep(3)
    url = driver.current_url
    if SIGNED_OUT_URL_RE.search(url):
        if verbose:
            print("   not signed in - sitting on %s" % url[:90])
        return False
    src = driver.page_source
    hits = [m for m in SIGNED_IN_MARKERS if m in src]
    ok = "/feed" in url and bool(hits)
    if verbose:
        print("   url=%s | markers=%s -> %s"
              % (url[:60], hits or "none", "signed in" if ok else "NOT signed in"))
    return ok


def shot(label):
    path = os.path.join(TEXT_DIR, re.sub(r"[^A-Za-z0-9_.-]", "_", label) + ".png")
    try:
        driver.save_screenshot(path)
        print("   screenshot -> " + path)
    except Exception:
        pass

# ---------------------------------------------------------------- helpers


def human_pause():
    # A flat uniform delay is itself a signature. Most human gaps are short, with an
    # occasional long one, so the short end is weighted and a tail is added now and then.
    d = random.uniform(MIN_DELAY, MAX_DELAY)
    if random.random() < 0.15:
        d += random.uniform(5, 20)
    time.sleep(d)


def goto(url, wait_css=None, timeout=20, strict=True):
    human_pause()
    try:
        driver.get(url)
    except TimeoutException:
        pass
    if wait_css:
        try:
            WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, wait_css)))
        except TimeoutException:
            pass
    else:
        time.sleep(1.5)
    if strict:
        try:
            here = driver.current_url
        except WebDriverException:
            raise Blocked("the browser window was closed")
        if SIGNED_OUT_URL_RE.search(here):
            raise Blocked("bounced to " + here[:120])


def scroll_page(times=4, pause=1.0):
    last = 0
    for _ in range(times):
        # vary both the distance and the dwell: real scrolling is not uniform
        driver.execute_script("window.scrollBy(0, document.body.scrollHeight*%.2f);"
                              % random.uniform(0.55, 0.9))
        time.sleep(pause * random.uniform(0.7, 1.6))
        h = driver.execute_script("return document.body.scrollHeight")
        if h == last:
            break
        last = h
    driver.execute_script("window.scrollTo(0, 0);")


# Clicks every "see more" / "...more" toggle. Matched on button TEXT and aria-label, never
# on class names, because LinkedIn's classes are hashed and change on every deploy.
# Without this, long posts and About sections stay truncated at "...more".
EXPAND_JS = r"""
// Click every "...more" toggle so long text is captured in full.
//
// Most of these toggles sit INSIDE an <a> that links to the post, so a plain click
// navigates away - that is how the profile page was being replaced by a feed update,
// taking the About section with it. A capture-phase listener cancels the link's default
// navigation while still letting the button's own expand handler run.
var n = 0;
var root = document.querySelector('main') || document.body;
var block = function (e) {
  var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
  if (a) { e.preventDefault(); }
};
document.addEventListener('click', block, true);
try {
  root.querySelectorAll('button').forEach(function (b) {
    if (b.closest('nav') || b.closest('header')) { return; }
    // A toggle inside an <a> cannot be clicked safely: LinkedIn's router navigates
    // programmatically, so preventDefault does not stop it. Those are the activity
    // preview cards, whose full text we get from the activity page anyway.
    if (b.closest('a')) { return; }
    var t = (b.innerText || '').replace(/\s+/g, ' ').trim();
    var al = (b.getAttribute('aria-label') || '').toLowerCase();
    // the ellipsis form only: a bare "More" is the profile's action menu, not an expander
    var isMore = /\u2026\s*more$/i.test(t) || /^see more$/i.test(t);
    if (isMore || al.indexOf('see more') >= 0
        || al.indexOf('show more') >= 0 || al.indexOf('expand post') >= 0) {
      try { b.click(); n++; } catch (e) {}
    }
  });
} finally {
  document.removeEventListener('click', block, true);
}
return n;
"""


def expand_show_more(rounds=2):
    total = 0
    for _ in range(rounds):
        try:
            n = driver.execute_script(EXPAND_JS) or 0
        except WebDriverException:
            break
        total += n
        if not n:
            break
        time.sleep(0.6)
    return total


def text_of(html):
    """The visible text of a page already in hand, which is what gets archived."""
    soup = BeautifulSoup(html, "lxml")
    for junk in soup(["script", "style", "noscript"]):
        junk.decompose()
    main = soup.find("main") or soup
    return re.sub(r"\n{3,}", "\n\n", main.get_text("\n", strip=True))


def read_page():
    """The current page as (html, text), fetched once.

    Reading driver.page_source serialises the whole DOM and sends it over the WebDriver
    connection. Callers that want both the markup and the text used to ask for it twice.
    """
    html = driver.page_source
    return html, text_of(html)


def page_text():
    return text_of(driver.page_source)


def dump_text(tag, text=None):
    tag = re.sub(r"[^A-Za-z0-9_.-]", "_", tag)[:80]
    path = os.path.join(TEXT_DIR, tag + ".txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text if text is not None else page_text())
    return path


def slug_of(url):
    m = re.search(r"/in/([^/?#]+)", url or "")
    return m.group(1) if m else ""


def p_blocks(node):
    out = []
    for p in node.find_all("p"):
        t = re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
        if t and t not in out:
            out.append(t)
    return out

# ---------------------------------------------------------------- India filter

# "Greater Bengaluru Area" and the like never contain the word India, so match cities too.
INDIA_CITY_RE = re.compile(
    r"\b(bengaluru|bangalore|mumbai|bombay|delhi|new delhi|noida|gurgaon|gurugram|"
    r"hyderabad|secunderabad|chennai|madras|pune|kolkata|calcutta|ahmedabad|jaipur|"
    r"chandigarh|lucknow|kochi|cochin|coimbatore|indore|bhopal|nagpur|surat|vadodara|"
    r"visakhapatnam|vizag|thiruvananthapuram|trivandrum|mysuru|mysore|mangaluru|"
    r"mangalore|nashik|rajkot|patna|bhubaneswar|guwahati|dehradun|ludhiana|amritsar|"
    r"faridabad|ghaziabad|thane|navi mumbai|goa|karnataka|maharashtra|telangana|"
    r"tamil nadu|kerala|gujarat|haryana|punjab|rajasthan|uttar pradesh|west bengal|"
    r"andhra pradesh|madhya pradesh|odisha|bihar|assam|jharkhand|chhattisgarh|"
    r"uttarakhand|himachal)\b", re.I)
NOT_INDIA_RE = re.compile(r"\b(indiana|indianapolis)\b", re.I)


def is_india(location):
    loc = (location or "").strip()
    if not loc:
        return False
    if NOT_INDIA_RE.search(loc):
        return False
    return bool(re.search(r"\bindia\b", loc, re.I)) or bool(INDIA_CITY_RE.search(loc))

# ---------------------------------------------------------------- search

JUNK_NAMES = {"", "linkedin member", "status is offline", "status is reachable"}
IN_RE = re.compile(r"/in/")
# trailing connection degree on the name line, e.g. "Jane Doe - 2nd"
DEGREE_RE = re.compile(r"[·•∙|]\s*(1st|2nd|3rd\+?|Following|Connect)\s*$", re.I)


def search_queries():
    return ["%s %s" % (COMPANY, term) for term in ROLE_TERMS]


def search_url(query, page=1):
    url = "https://www.linkedin.com/search/results/people/?keywords=" + quote_plus(query)
    if INDIA_ONLY:
        url += "&geoUrn=%5B%22" + INDIA_GEO_URN + "%22%5D"
    if page > 1:
        url += "&page=" + str(page)
    return url


def parse_search_results(html):
    # LinkedIn ships hashed CSS classes (l4jkxn, ...) that change every deploy, so match on
    # structure: a result card is an /in/ anchor with no /in/ anchor above it. Mutual-connection
    # links are always nested inside a card anchor, which is what excludes them.
    soup = BeautifulSoup(html, "lxml")
    main = soup.find("main") or soup
    people, seen = [], set()

    for a in main.select('a[href*="/in/"]'):
        if a.find_parent("a", href=IN_RE):
            continue
        slug = slug_of(a.get("href", ""))
        if not slug or slug in seen:
            continue

        blocks = []
        for p in a.find_all("p"):
            t = re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
            if t and t not in blocks:
                blocks.append(t)
        if not blocks:
            continue

        name = DEGREE_RE.sub("", blocks[0]).strip(" ·•|")
        if len(name) < 2 or name.lower() in JUNK_NAMES:
            continue

        rest = blocks[1:]
        mutual = next((t for t in rest if "mutual connection" in t.lower()), "")
        rest = [t for t in rest if t != mutual]
        # LinkedIn's AI blurb is an extra long paragraph after headline + location
        summary = ""
        if len(rest) > 2:
            summary = max(rest[2:], key=len)
            rest = rest[:2]

        seen.add(slug)
        people.append({
            "slug": slug,
            "name": name,
            "headline": rest[0] if rest else "",
            "location": rest[1] if len(rest) > 1 else "",
            "ai_summary": summary,
            "mutual_connections": mutual,
            "profile_url": "https://www.linkedin.com/in/" + slug + "/",
        })
    return people


def collect_people(pages=None):
    pages = pages if pages is not None else PAGES_PER_QUERY
    found = {}

    if os.path.exists(INDEX_JSON):
        with open(INDEX_JSON, encoding="utf-8") as f:
            for r in json.load(f):
                found[r["slug"]] = r
        print("%d people already in the index" % len(found))

    skipped = 0
    for q in search_queries():
        print("\n=== %s ===" % q)
        for page in range(1, pages + 1):
            goto(search_url(q, page), wait_css="main", strict=False)
            scroll_page(times=3, pause=0.8)

            if "/search/results/people" not in driver.current_url:
                print("  page %2d: redirected to %s - rate-limited or signed out. Stopping query."
                      % (page, driver.current_url))
                dump_text("search_redirect_%s_%d" % (company_slug(q), page))
                shot("search_redirect_%s_%d" % (company_slug(q), page))
                break

            rows = parse_search_results(driver.page_source)
            new = 0
            for r in rows:
                if INDIA_ONLY and not is_india(r.get("location")):
                    skipped += 1
                    continue
                if r["slug"] not in found:
                    r["found_via"] = q
                    found[r["slug"]] = r
                    new += 1
            print("  page %2d: %2d results (%2d new india, %3d total)"
                  % (page, len(rows), new, len(found)))

            if not rows:
                dump_text("search_empty_%s_%d" % (company_slug(q), page))
                print("  nothing parsed - end of results, or selectors need a look.")
                break

    with open(INDEX_JSON, "w", encoding="utf-8") as f:
        json.dump(list(found.values()), f, indent=2, ensure_ascii=False)
    print("\n%d people in index (%d non-India skipped) -> %s"
          % (len(found), skipped, INDEX_JSON))
    return list(found.values())

# ---------------------------------------------------------------- profile header

# throwaway fragments in the profile header: degree badges, counters, action buttons
JUNK_P_RE = re.compile(
    r"^(\W*(1st|2nd|3rd\+?)\W*|Contact info|connections?|followers?|[\d,]+\+?|"
    r"Message|Connect|Follow|More|Save in Sales Navigator|\W+)$", re.I)


def scrape_top_card(soup):
    # the profile name is an <h2>; these pages carry no <h1> at all
    main = soup.find("main") or soup
    out = {"name_profile": "", "headline_profile": "", "location_profile": ""}

    h2 = main.find("h2")
    if h2:
        out["name_profile"] = h2.get_text(" ", strip=True)

    raw = p_blocks(main)[:16]
    clean = [t for t in raw if not JUNK_P_RE.match(t)]
    if clean:
        out["headline_profile"] = clean[0]
    if "Contact info" in raw:
        before = [t for t in raw[:raw.index("Contact info")] if not JUNK_P_RE.match(t)]
        if len(before) >= 2:
            out["location_profile"] = before[-1]
    elif len(clean) > 2:
        out["location_profile"] = clean[2]
    return out


# Section order on a profile is: top card, About, Activity, Experience, ...
# so the About body is whatever sits between the About heading and the next heading.
ABOUT_STOP_RE = re.compile(
    r"^(Activity|Experience|Education|Licenses|Skills|Recommendations|Interests|"
    r"Accomplishments|Featured|Top skills|Highlights|Services|Courses|Projects|"
    r"Publications|Languages|Volunteering|Honors|Organizations|People also viewed|"
    r"Show all|Followers|Following|Accessibility|Talent Solutions|Community Guidelines|"
    r"Careers|Marketing Solutions|Privacy|Ad Choices|Advertising|Sales Solutions|"
    r"Mobile|Small Business|Safety Center|Questions|Manage your account)\b", re.I)


def scrape_about_text(profile_text):
    """Pull the About paragraph out of the page text.

    Done on text rather than the DOM because the About heading is the only stable
    landmark - the section wrapper's id and classes are generated per deploy. LinkedIn's
    page footer also contains a bare 'About' link, so a candidate only counts when real
    prose follows it, and the longest such candidate wins.
    """
    lines = [l.strip() for l in (profile_text or "").split("\n") if l.strip()]
    best = ""
    for i, line in enumerate(lines):
        if line.lower() != "about":
            continue
        body = []
        for nxt in lines[i + 1:i + 60]:
            if ABOUT_STOP_RE.match(nxt) or nxt.lower() == "about":
                break
            if nxt.lower() in ("…", "more", "see more", "…more", "follow",
                               "message", "·", "top skills"):
                continue
            if len(nxt) < 3:
                continue
            body.append(nxt)
        text = "\n".join(body).strip()
        # A short floor, because a one-line About ("Engineering leader, ex-Flipkart.")
        # is still the description that was asked for. The footer's own "About" link
        # cannot sneak through it: every line following that one is a footer link matched
        # by ABOUT_STOP_RE, so that candidate's body comes out empty.
        if len(text) > len(best) and len(text) >= 15:
            best = text
    return best


def scrape_about_dom(soup):
    main = soup.find("main") or soup
    # LinkedIn gives each profile section an anchor div with a plain, stable id
    # (<div id="about" class="pv-profile-card__anchor">) for in-page links. Unlike the
    # hashed class names, that id survives deploys, so it is worth trying first.
    anchor = main.find(id="about")
    if anchor:
        sec = anchor.find_parent("section") or anchor.parent
        blocks = [t for t in p_blocks(sec) if t.strip().lower() != "about"]
        if blocks:
            return max(blocks, key=len)
    for h in main.find_all(["h2", "h3"]):
        if h.get_text(strip=True).lower() == "about":
            sec = h.find_parent("section") or h.parent
            blocks = [t for t in p_blocks(sec) if t.lower() != "about"]
            if blocks:
                return max(blocks, key=len)
    return ""

# ---------------------------------------------------------------- experience

EMP_TYPE_RE = re.compile(
    r"\b(Full-time|Part-time|Contract|Internship|Freelance|Self-employed|Seasonal|"
    r"Apprenticeship|Permanent|Temporary)\b", re.I)
DATE_LINE_RE = re.compile(
    r"^((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?(19|20)\d{2}\s*[-–]\s*"
    r"((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?((19|20)\d{2}|Present)", re.I)
MIDDOT = "·"
# second line of a company group header: "Full-time - 6 yrs 5 mos", or just "4 yrs"
DURATION_RE = re.compile(
    r"^(?:(?:Full-time|Part-time|Contract|Internship|Freelance|Self-employed|Seasonal|"
    r"Apprenticeship|Permanent|Temporary)\s*[·-]?\s*)?\d+\s*(?:yr|yrs|mo|mos)\b", re.I)
NOISE_RE = re.compile(r"^(Ad Options|Why am I seeing this ad|Don.t want to see this|"
                      r"Experience|More profiles|People you may know|Show all)", re.I)


MONTH_NUM = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun",
     "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}
RANGE_RE = re.compile(
    r"^(?:([A-Za-z]{3,9})\s+)?((?:19|20)\d{2})\s*[-–]\s*"
    r"(?:(?:([A-Za-z]{3,9})\s+)?((?:19|20)\d{2})|(Present))", re.I)


def parse_date_range(dates):
    """'Jan 2019 - Present' -> (start, end) as absolute month numbers."""
    m = RANGE_RE.match((dates or "").strip())
    if not m:
        return None
    sm, sy, em, ey, present = m.groups()
    start = int(sy) * 12 + MONTH_NUM.get((sm or "jan")[:3].lower(), 1)
    if present:
        end = TODAY.year * 12 + TODAY.month
    else:
        end = int(ey) * 12 + MONTH_NUM.get((em or "dec")[:3].lower(), 12)
    if end < start:
        start, end = end, start
    return start, end


DUR_PARTS_RE = re.compile(r"(\d+)\s*(yrs?|mos?)\b", re.I)


def duration_months(text):
    """'5 yrs 7 mos' -> 67. Reads the duration LinkedIn itself prints."""
    total = 0
    for n, unit in DUR_PARTS_RE.findall(text or ""):
        total += int(n) * (12 if unit.lower().startswith("yr") else 1)
    return total


def parse_experience_text(text):
    """Parse the experience list from page TEXT, not the DOM.

    LinkedIn's CSS classes are hashed and regenerated per deploy, so every role is
    anchored on its date line instead. Three layouts occur around that line:

      A grouped    "Tesco Bengaluru" / "5 yrs 7 mos"          <- company header
                   "Senior Manager" / ["Full-time"] / "May 2016 - Nov 2017"
      B ungrouped  "Senior Manager" / "Tesco Bengaluru - Full-time" / dates
      C bare       "Team Manager" / "Dell" / dates

    A group header is a line followed by a bare duration. The group closes once its roles
    have used up the header's total, which is what stops a later employer's roles from
    being credited to it: a profile lists several groups one after another and nothing
    else marks where one ends.
    """
    lines = [l.strip() for l in (text or "").split("\n") if l.strip()]
    date_idx = [i for i, l in enumerate(lines) if DATE_LINE_RE.match(l)]
    rows = []
    group, group_total, group_used = "", 0, 0

    for i, line in enumerate(lines):
        nxt = lines[i + 1] if i + 1 < len(lines) else ""

        # layout A header: company name on one line, its total duration on the next.
        # Requiring that duration is what keeps a role title followed by a bare
        # "Full-time" from being mistaken for a new company header.
        if (nxt and DURATION_RE.match(nxt) and not DATE_LINE_RE.match(nxt)
                and not DATE_LINE_RE.match(line) and not NOISE_RE.match(line)
                and not EMP_TYPE_RE.match(line)):
            group, group_total, group_used = line, duration_months(nxt), 0
            continue

        if not DATE_LINE_RE.match(line):
            continue

        prev = lines[i - 1] if i >= 1 else ""
        prev2 = lines[i - 2] if i >= 2 else ""
        prev3 = lines[i - 3] if i >= 3 else ""

        if MIDDOT in prev and EMP_TYPE_RE.search(prev) and not EMP_TYPE_RE.match(prev):
            company, title = prev.split(MIDDOT)[0].strip(), prev2   # layout B
            group, group_total, group_used = "", 0, 0
        elif group:
            # layout A; a bare "Full-time" sits between the title and the dates
            company = group
            title = prev2 if EMP_TYPE_RE.match(prev) else prev
            if EMP_TYPE_RE.match(prev) and EMP_TYPE_RE.match(prev2 or ""):
                title = prev3
        else:
            company, title = prev, prev2                            # layout C

        nxt_date = next((d for d in date_idx if d > i), len(lines))
        tail = [t for t in lines[i + 1:max(i + 1, nxt_date - 1)] if not NOISE_RE.match(t)]
        location = ""
        if tail and not DATE_LINE_RE.match(tail[0]) and len(tail[0]) <= 90:
            location = tail[0]
            tail = tail[1:]

        title = (title or "").strip()
        if not title or NOISE_RE.match(title) or title == company:
            continue
        rows.append({
            "title": title,
            "company": company.strip(),
            "dates": line,
            "location": location,
            "description": " ".join(t for t in tail if t not in (company, title)).strip(),
            "raw": " | ".join(lines[max(0, i - 3):i + 2]),
        })

        # close the group once its roles account for the header's total
        if group and group_total:
            span = parse_date_range(line)
            group_used += duration_months(line) or (span[1] - span[0] + 1 if span else 0)
            if group_used >= group_total:
                group, group_total, group_used = "", 0, 0
    return rows


# legal suffixes and group words that differ between how people type a company name
COMPANY_NOISE_RE = re.compile(
    r"\b(ltd|limited|plc|inc|incorporated|llc|llp|pvt|private|corp|corporation|co|"
    r"company|group|holdings|holding|technologies|technology|services|solutions|"
    r"global|international|india|bengaluru|bangalore|gcc|hsc)\b", re.I)


def norm_company(name):
    s = re.sub(r"[^a-z0-9 ]+", " ", (name or "").lower())
    s = COMPANY_NOISE_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def company_matches(row_company, target=None):
    """True when an experience row belongs to the company we asked for.

    Compared on normalised tokens so "Tesco Bengaluru", "Tesco PLC" and "Tesco" all match,
    while "Tescore" or an unrelated employer does not. Token equality is required, never a
    substring, which is what keeps "Tesco" from matching "Tescore Analytics".
    """
    target = norm_company(target if target is not None else COMPANY)
    if not target:
        return True
    row = norm_company(row_company)
    if not row:
        return False
    t_tokens, r_tokens = target.split(), set(row.split())
    return bool(t_tokens) and all(t in r_tokens for t in t_tokens)


def months_to_text(months):
    y, m = divmod(max(0, int(months)), 12)
    parts = []
    if y:
        parts.append("%d yr%s" % (y, "s" if y != 1 else ""))
    if m or not y:
        parts.append("%d mo%s" % (m, "s" if m != 1 else ""))
    return " ".join(parts)


def tenure_months(rows):
    """Total months at the company, merging overlapping roles so none is double counted."""
    spans = sorted(s for s in (parse_date_range(r.get("dates")) for r in rows) if s)
    if not spans:
        return 0
    merged = [list(spans[0])]
    for start, end in spans[1:]:
        if start <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    # the end month counts as worked, so a Jan-Jan span is one month
    return sum(e - s + 1 for s, e in merged)


def company_experience(rows, target=None):
    """The rows for the target company only, newest first, plus total tenure in months."""
    hits = [dict(r) for r in (rows or []) if company_matches(r.get("company"), target)]
    for r in hits:
        span = parse_date_range(r.get("dates"))
        r["duration"] = months_to_text(span[1] - span[0] + 1) if span else ""
        r["_end"] = span[1] if span else 0
    hits.sort(key=lambda r: r.get("_end", 0), reverse=True)
    for r in hits:
        r.pop("_end", None)
    return hits, tenure_months(hits)


def scrape_experience(slug):
    goto("https://www.linkedin.com/in/" + slug + "/details/experience/", wait_css="main")
    # The role list is what this page is for, so it still gets scrolled until the page
    # stops growing - but with a shorter dwell, and the expander is a single pass: it
    # only opens role descriptions, which are a bonus field, not the tenure figures.
    scroll_page(times=3, pause=0.55)
    expand_show_more(rounds=1)
    txt = page_text()
    return parse_experience_text(txt), txt


ABOUT_EXPAND_JS = r"""
// Expand the About paragraph only, by finding the section through its anchor id and
// clicking the "...more" button inside it. Scoping it this tightly matters: the generic
// expander has to skip toggles that sit inside <a> tags, because clicking one navigates
// away and the profile gets recorded as a feed post. Nothing inside About is a link.
var a = document.getElementById('about');
var sec = a ? (a.closest('section') || a.parentElement) : null;
if (!sec) { return -1; }
var n = 0;
sec.querySelectorAll('button').forEach(function (b) {
  if (b.closest('a')) { return; }
  var t = (b.innerText || '').replace(/\s+/g, ' ').trim();
  var al = (b.getAttribute('aria-label') || '').toLowerCase();
  if (/\u2026\s*more$/i.test(t) || /^see more$/i.test(t)
      || al.indexOf('see more') >= 0 || al.indexOf('show more') >= 0) {
    try { b.scrollIntoView({block: 'center'}); b.click(); n++; } catch (e) {}
  }
});
return n;
"""


def expand_about():
    """Click the About section's own "...more", returning how many toggles were hit."""
    try:
        return driver.execute_script(ABOUT_EXPAND_JS) or 0
    except WebDriverException:
        return 0


def ensure_about(slug="", max_steps=4, text=None):
    """Return the About text, re-reading after each expand attempt.

    Pass `text` when the page text has already been read, so the common case - the
    paragraph is in the page and needs no expanding - costs no parse at all.

    The description is the field that matters most here, so this does not give up after
    one try. It expands the About section directly first, then falls back to the generic
    expander, and re-reads the page each time. It also tries the DOM, because a
    paragraph broken into several short lines can fall under the text parser's length
    floor while still being plainly present in the markup.
    """
    about = scrape_about_text(text if text is not None else page_text())
    clicked_any = False
    for n in range(max_steps):
        if about or (slug and not on_profile(slug)):
            break
        clicked = expand_about()
        clicked_any = clicked_any or clicked > 0
        if clicked <= 0:
            # -1 means the section is not in the page at all: either still rendering, or
            # this person genuinely has no About. Give the render a moment, then try the
            # page-wide expander once before concluding there is nothing to find.
            if clicked < 0 and n == 0:
                time.sleep(1.2)
                scroll_page(times=1, pause=0.6)
            else:
                n_generic = expand_show_more(rounds=1)
                clicked_any = clicked_any or n_generic > 0
                if not n_generic:
                    break
        time.sleep(0.5)
        about = scrape_about_text(page_text())
    if not about and (not slug or on_profile(slug)):
        try:
            about = scrape_about_dom(BeautifulSoup(driver.page_source, "lxml"))
        except WebDriverException:
            pass
    return about, clicked_any


MIN_PROFILE_LINES = 150

# Does the page have a name heading and at least one section anchor? Asked in the
# browser, so nothing is transferred or re-parsed. LinkedIn gives each profile section
# an anchor div with a plain id for in-page links, and those ids are not hashed.
RENDERED_JS = (
    "var m = document.querySelector('main');"
    "if (!m) { return 0; }"
    "if (!m.querySelector('h1')) { return 0; }"
    "return m.querySelectorAll('#about, #experience, #education, #skills').length;")


def rendered_enough():
    try:
        return bool(driver.execute_script(RENDERED_JS))
    except WebDriverException:
        return False


def wait_rendered(slug, tries=7):
    """Wait until the profile has painted, then read its text once.

    A profile still rendering yields a stub of ~100 lines where a finished one gives
    500+, and reading that stub loses the About section silently - it looks identical
    to a person who has none.

    The waiting is done with the cheap in-browser check above rather than by reading the
    text each time round. page_text() ships the whole document over and re-parses it,
    which was the most expensive thing this script did per profile - and it was doing it
    up to seven times just to find out whether the page was ready.
    """
    for n in range(tries):
        if rendered_enough() or not on_profile(slug):
            break
        # one reload part-way through: a page that stalled on first load usually comes
        # back complete, while waiting longer on a dead render achieves nothing
        if n == 3:
            try:
                driver.get("https://www.linkedin.com/in/%s/" % slug)
                time.sleep(2.5)
            except WebDriverException:
                break
        time.sleep(0.8 + 0.5 * n)
        scroll_page(times=1, pause=0.4)

    html, txt = read_page()
    # The anchors can be in place while the body is still filling in, so the line count
    # still has the final say - but now it costs one extra read instead of seven.
    if len([l for l in txt.split("\n") if l.strip()]) < MIN_PROFILE_LINES \
            and on_profile(slug):
        time.sleep(1.5)
        scroll_page(times=1, pause=0.5)
        html, txt = read_page()
    return html, txt


def on_profile(slug):
    """Still on this person's profile page, rather than somewhere a click took us."""
    try:
        return ("/in/" + slug.lower()) in driver.current_url.lower()
    except WebDriverException:
        return False


def scrape_profile(person):
    slug = person["slug"]
    rec = dict(person)
    rec["company_target"] = COMPANY

    goto(person["profile_url"], wait_css="main")
    if "/in/" not in driver.current_url:
        # not a signed-out bounce (goto would have raised); a dead or renamed profile
        rec["error"] = "redirected to " + driver.current_url
        return rec

    # One scroll, not three. Everything wanted from this page - the top card and the
    # About section - sits at the top; wait_rendered scrolls again only if the page has
    # not finished painting, so a fast-loading profile costs nothing extra.
    scroll_page(times=1, pause=0.5)
    # Snapshot before any clicking. If an expand click still manages to navigate, this
    # pristine copy is what gets used, so a profile can never be recorded as some other
    # page's content.
    clean_html, clean_txt = wait_rendered(slug)

    # Only the About toggle is clicked, never every toggle on the page. The page-wide
    # expander existed to open post previews, which are no longer collected; dropping it
    # saves a dozen clicks and a re-render per profile, and removes the drift risk
    # (those preview toggles were the ones that navigated away).
    about, clicked = (ensure_about(slug, text=clean_txt) if SCRAPE_ABOUT
                      else ("", False))

    if not clicked:
        # nothing was clicked, so the page is exactly what was already captured: no
        # reason to ship the document over and parse it a second time
        soup = BeautifulSoup(clean_html, "lxml")
        profile_txt = clean_txt
    elif on_profile(slug):
        html, profile_txt = read_page()
        soup = BeautifulSoup(html, "lxml")
    else:
        print("      (drifted off %s, using the pre-click capture)" % slug)
        soup = BeautifulSoup(clean_html, "lxml")
        profile_txt = clean_txt
        about = about or scrape_about_text(clean_txt)

    top = scrape_top_card(soup)
    if top.get("name_profile", "").lower() in ("feed post", "premium", "", "linkedin"):
        # the header did not come from a profile page; keep what search already gave us
        top = {"name_profile": person.get("name", ""),
               "headline_profile": person.get("headline", ""),
               "location_profile": person.get("location", "")}
    rec.update(top)
    rec["about"] = (about or scrape_about_text(profile_txt)
                    or scrape_about_dom(soup)) if SCRAPE_ABOUT else ""

    all_exp, exp_txt = scrape_experience(slug) if SCRAPE_EXPERIENCE else ([], "")

    # archive the visible text of both pages, so reparse can rebuild every field offline
    full = ("===== PROFILE =====\n" + profile_txt
            + "\n\n===== EXPERIENCE =====\n" + exp_txt)
    rec["text_file"] = dump_text(slug, full)
    rec["profile_text"] = profile_txt
    rec["experience_text"] = exp_txt

    rec["render_ok"] = len([l for l in profile_txt.split("\n") if l.strip()]) \
        >= MIN_PROFILE_LINES
    rec["experience_all"] = all_exp
    derive(rec)
    return rec


def derive(rec):
    """Fill the reported fields from the raw ones. Used by the scrape and by reparse."""
    target = rec.get("company_target") or COMPANY
    exp, tenure = company_experience(rec.get("experience_all") or [], target)
    rec["experience"] = exp
    rec["n_experience"] = len(exp)
    rec["yoe_at_company_months"] = tenure
    rec["yoe_at_company"] = months_to_text(tenure) if tenure else ""
    rec["yoe_at_company_years"] = round(tenure / 12.0, 1) if tenure else 0.0
    rec["company_resolved"] = exp[0]["company"] if exp else ""
    if exp:
        rec["designation"] = exp[0]["title"]
        rec["designation_source"] = "experience"
    else:
        # no row matched the company, so fall back to the headline and say so, which keeps
        # the guess auditable instead of passing it off as parsed data
        rec["designation"] = rec.get("headline_profile") or rec.get("headline", "")
        rec["designation_source"] = "headline"

    rec["location_final"] = rec.get("location_profile") or rec.get("location", "")
    rec["is_india"] = is_india(rec["location_final"])
    return rec

# ---------------------------------------------------------------- run


def load_records():
    records = []
    if os.path.exists(JSONL):
        with open(JSONL, encoding="utf-8") as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    return records


def already_done():
    return set(r.get("slug") for r in load_records() if r.get("slug"))


BLOCK_HELP = """
LinkedIn has stopped serving pages to this session. Nothing is lost - %d people are
saved and the run resumes from there.

This is a rate limit, not a bug. It is counted per session, so it can trip on a long
run even at a sensible pace.

What to do:
  1. Close the script and leave LinkedIn alone for a few hours. Same day is usually
     enough; a day is safer.
  2. Open LinkedIn in your normal browser and check for a security prompt waiting for
     you. Clear it there, as a human.
  3. Then:  python linkedin_win.py scrape --limit 20
     Short runs with a pause between them get through where one long run does not.

If signing in starts looping - the page reloading every second, never settling - the
saved session is stale and Chrome keeps replaying it. Reset it:
       python linkedin_win.py reset-session
       python linkedin_win.py login
That deletes %s and signs you in fresh.
"""


def fmt_eta(seconds):
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, _ = divmod(rem, 60)
    return "%dh%02dm" % (h, m) if h else "%dm" % m


def run_profiles(index, limit=None):
    limit = limit if limit is not None else MAX_PROFILES
    done = already_done()
    todo = [p for p in index if p["slug"] not in done]
    if INDIA_ONLY:
        before = len(todo)
        todo = [p for p in todo if is_india(p.get("location"))]
        if before != len(todo):
            print("%d non-India people in the index skipped" % (before - len(todo)))
    if limit:
        todo = todo[:limit]

    print("\n%d already scraped | %d to go\n" % (len(done), len(todo)))
    started, fails, no_desc, got = time.time(), 0, 0, 0

    with open(JSONL, "a", encoding="utf-8") as out:
        for i, person in enumerate(todo, 1):
            if i > 1 and (i - 1) % LONG_BREAK_EVERY == 0:
                nap = int(LONG_BREAK_SECS * random.uniform(0.7, 1.4))
                print("   ... long break, %d min (looks like stepping away)" % (nap // 60))
                time.sleep(nap)
            elif i > 1 and (i - 1) % COOLDOWN_EVERY == 0:
                nap = int(COOLDOWN_SECS * random.uniform(0.6, 1.5))
                print("   ... pausing %ds" % nap)
                time.sleep(nap)
            label = "[%3d/%3d] %-32s" % (i, len(todo), person["name"][:32])
            try:
                rec = scrape_profile(person)
                out.write(json.dumps(rec, ensure_ascii=False) + "\n")
                out.flush()
                per = (time.time() - started) / i
                if not rec.get("render_ok", True):
                    print("      (page did not fully render - run redo-incomplete later)")
                # the description is the headline result, so its size is what gets
                # reported: NONE means the person left the section blank
                print("%s roles=%-2d %-12s desc=%-5s %3.0fs eta %s"
                      % (label, rec.get("n_experience", 0),
                         (rec.get("yoe_at_company") or "-")[:12],
                         len(rec.get("about") or "") or "NONE",
                         per, fmt_eta(per * (len(todo) - i))))
                if not (rec.get("about") or "").strip():
                    no_desc += 1
                fails = 0
                got += 1
            except Blocked as e:
                print("%s BLOCKED: %s" % (label, e))
                print(BLOCK_HELP % (len(done) + i - 1, PROFILE_DIR))
                shot("blocked")
                break
            except KeyboardInterrupt:
                print("\nStopped. Progress is saved.")
                break
            except Exception as e:
                fails += 1
                print("%s FAILED: %s: %s" % (label, type(e).__name__, e))
                traceback.print_exc(limit=1)
                if fails >= 5:
                    print("\n5 failures in a row - stopping. Usually signed out or rate-limited.")
                    shot("run_failure")
                    break
                time.sleep(20)

    if got:
        print("\n%d of %d have a description; %d have none."
              % (got - no_desc, got, no_desc))
    print("Saved to " + JSONL)

# ---------------------------------------------------------------- export


ITEM_SEP = "  ||  "      # between numbered items inside one cell
FIELD_SEP = " | "        # between a role's fields
HEAD_SEP = " -- "        # between an item's header and its body


def one_line(value, limit=32000):
    """Flatten a value into a single CSV cell.

    Every cell is forced onto one physical line. A cell containing a real newline turns
    one record into several lines in the file, which is exactly what makes a CSV look
    misaligned in anything that is not a spreadsheet - and even in Excel a 35,000
    character cell is rejected outright, since the limit is 32,767. Nothing is lost by
    trimming here: people.json always holds the full, unflattened text.
    """
    s = "" if value is None else str(value)
    s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", s)
    s = re.sub(r"[\n\r\t]+", " ", s)
    s = re.sub(r" {2,}", " ", s).strip()
    if len(s) > limit:
        s = s[:limit - 45].rstrip() + " ...[truncated - full text in people.json]"
    return s


def experience_cell(exp):
    """Every role at the target company numbered inside one cell, on one line."""
    out = []
    for i, e in enumerate(exp or [], 1):
        bits = [b for b in (e.get("company"), e.get("dates"), e.get("duration"),
                            e.get("location")) if b]
        line = "%d. %s" % (i, e.get("title") or "?")
        if bits:
            line += FIELD_SEP + FIELD_SEP.join(bits)
        if e.get("description"):
            line += HEAD_SEP + e["description"]
        out.append(line)
    return ITEM_SEP.join(out)


def person_json(r):
    """One person: the five fields asked for, with the full untrimmed text.

    The CSV carries the same data flattened onto one line; this keeps the description
    exactly as written, paragraph breaks included, and the roles as real objects.
    """
    return {
        "sr_no": r["sr_no"],
        "name": r.get("name", ""),
        "location": r.get("location_final", ""),
        "title": r.get("designation", ""),
        "yoe_at_company": r.get("yoe_at_company", ""),
        "yoe_at_company_years": r.get("yoe_at_company_years", 0),
        "about": r.get("about", ""),
        "experience_at_company": [
            dict((k, e.get(k, "")) for k in
                 ("title", "company", "dates", "duration", "location", "description"))
            for e in (r.get("experience") or [])],
        "company": r.get("company_resolved") or r.get("company_target", ""),
        "profile_url": r.get("profile_url", ""),
        # where the title came from: 'experience' is parsed, 'headline' means no role at
        # this company matched, so the title is the profile's own headline instead
        "title_source": r.get("designation_source", ""),
        "render_ok": r.get("render_ok", True),
        "error": r.get("error", ""),
    }


# Name, location, title, experience, About - and nothing else. The short columns come
# first so the sheet reads across without scrolling; the two long text cells go last,
# where a wide column does not push everything else off the screen.
FINAL_COLS = ["sr_no", "name", "location", "title", "yoe_at_company", "yoe_years",
              "n_roles", "profile_url", "about", "experience"]


def final_row(r):
    return {
        "sr_no": r["sr_no"],
        "name": r.get("name", ""),
        "location": r.get("location_final", ""),
        "title": r.get("designation", ""),
        "yoe_at_company": r.get("yoe_at_company", ""),
        "yoe_years": r.get("yoe_at_company_years", 0),
        "n_roles": r.get("n_experience", 0),
        "profile_url": r.get("profile_url", ""),
        "about": r.get("about", ""),
        "experience": experience_cell(r.get("experience") or []),
    }


# Files earlier versions wrote. Everything they held is now in people.json or
# final.csv, and a leftover copy would sit in the folder looking current while serving
# stale data, so export clears them out.
OBSOLETE = ["final.json", "experience.json", "posts.json",
            "people.csv", "experience.csv", "posts.csv"]


def export():
    """Write the two output files: people.json and final.csv."""
    records = load_records()
    print("%d profiles loaded from %s" % (len(records), JSONL))
    if not records:
        print("Nothing to export yet - run the scrape first.")
        return

    for r in records:
        derive(r)
    if INDIA_ONLY:
        kept = [r for r in records if r.get("is_india")]
        if len(kept) != len(records):
            print("%d non-India profiles left out of the export" % (len(records) - len(kept)))
        records = kept
    # longest tenure at the company first, which is the order these lists get read in
    records.sort(key=lambda r: (-(r.get("yoe_at_company_months") or 0),
                                r.get("name", "")))
    for i, r in enumerate(records, 1):
        r["sr_no"] = i

    # ---- people.json: every person, everything kept, nothing flattened
    people = [person_json(r) for r in records]
    jpath = os.path.join(OUT_DIR, "people.json")
    with open(jpath, "w", encoding="utf-8") as f:
        json.dump(people, f, indent=2, ensure_ascii=False)

    # ---- final.csv: one person per row, one row per line
    cols = list(FINAL_COLS)
    cpath = os.path.join(OUT_DIR, "final.csv")
    with open(cpath, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(cols)
        for r in records:
            row = final_row(r)
            w.writerow([one_line(row[c]) for c in cols])

    n_roles = sum(len(r.get("experience") or []) for r in records)
    with_desc = sum(1 for r in records if (r.get("about") or "").strip())
    print("people.json  %5d people, %d roles -> %s" % (len(people), n_roles, jpath))
    print("final.csv    %5d rows, %d columns -> %s" % (len(records), len(cols), cpath))
    print("             %d of %d have a description" % (with_desc, len(records)))

    for stale in OBSOLETE + ["linkedin_%s.xlsx" % company_slug(COMPANY)]:
        spath = os.path.join(OUT_DIR, stale)
        if os.path.exists(spath):
            try:
                os.remove(spath)
                print("removed the old %s (its data is in people.json)" % stale)
            except OSError:
                pass

# ---------------------------------------------------------------- cli


def ask_company(given=None):
    if given:
        return given.strip()
    saved = load_state().get("company", "")
    prompt = "Which company do you want data for"
    prompt += " [%s]: " % saved if saved else ": "
    try:
        answer = input(prompt).strip()
    except EOFError:
        answer = ""
    return answer or saved


def cmd_reset_session(args):
    """Delete the saved Chrome profile.

    The cure for a sign-in that reloads forever: LinkedIn's cookies and CSRF token have
    gone out of step, and Chrome replays the stale pair on every attempt. Nothing scraped
    is touched - only the browser session.
    """
    if not os.path.isdir(PROFILE_DIR):
        print("No saved session at " + PROFILE_DIR)
        return 0
    size = sum(os.path.getsize(os.path.join(dp, f))
               for dp, _, fs in os.walk(PROFILE_DIR) for f in fs) / 1e6
    print("About to delete the saved browser session:")
    print("  %s  (%.0f MB)" % (PROFILE_DIR, size))
    print("Collected data is in linkedin_out and is not affected.")
    try:
        if input("Delete it? [y/N]: ").strip().lower() not in ("y", "yes"):
            print("Left alone.")
            return 0
    except EOFError:
        print("Left alone (no answer).")
        return 0
    shutil.rmtree(PROFILE_DIR, ignore_errors=True)
    print("Deleted. Now run:  python linkedin_win.py login")
    return 0


def cmd_redo_incomplete(args):
    """Drop records whose profile page never finished rendering, so they get refetched.

    A stalled render yields a stub page with no About section, which is indistinguishable
    from a person who simply has none. Rather than guess, those records are removed and
    the next scrape collects them again - everything else is kept.
    """
    if apply_common(args) is None:
        return 1
    records = load_records()
    if not records:
        print("Nothing collected yet in " + OUT_DIR)
        return 1

    def complete(r):
        if r.get("render_ok") is not None:
            return r["render_ok"]
        lines = [l for l in (r.get("profile_text") or "").split("\n") if l.strip()]
        return len(lines) >= MIN_PROFILE_LINES

    keep = [r for r in records if complete(r)]
    drop = len(records) - len(keep)
    if not drop:
        print("All %d records look complete." % len(records))
        return 0

    print("%d of %d records have a stub profile page." % (drop, len(records)))
    try:
        if input("Drop them so the next scrape refetches them? [y/N]: ").strip().lower() \
                not in ("y", "yes"):
            print("Left alone.")
            return 0
    except EOFError:
        print("Left alone (no answer).")
        return 0

    with open(JSONL, "w", encoding="utf-8") as f:
        for r in keep:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("Kept %d. Now run the scrape again to refill the %d." % (len(keep), drop))
    return 0


def cmd_login(args):
    start_browser(headless=False, images=True)
    print("Chrome is open. Sign in to LinkedIn in that window.")
    print("Waiting up to %d minutes ...\n" % args.wait)
    try:
        driver.get("https://www.linkedin.com/login")
    except TimeoutException:
        pass

    deadline = time.time() + args.wait * 60
    while time.time() < deadline:
        time.sleep(5)
        try:
            url = driver.current_url
        except WebDriverException:
            print("Chrome was closed before sign-in completed.")
            return 1
        if (not SIGNED_OUT_URL_RE.search(url)
                and any(m in driver.page_source for m in SIGNED_IN_MARKERS)):
            print("Signed in. Session saved to " + PROFILE_DIR)
            print("Now run:  python linkedin_win.py scrape")
            stop_browser()
            return 0
        left = int(deadline - time.time())
        state = "challenge" if "checkpoint" in url else "signed out"
        print("  still waiting (%ds left) - %s - %s" % (left, state, url[:70]))
    print("Timed out waiting for sign-in.")
    stop_browser()
    return 1


def apply_common(args):
    global INDIA_ONLY, MIN_DELAY, MAX_DELAY
    INDIA_ONLY = not args.worldwide
    if getattr(args, "fast", False):
        MIN_DELAY, MAX_DELAY = FAST_DELAY
    company = ask_company(args.company)
    if not company:
        print("No company given - nothing to do.")
        return None
    set_company(company)
    return company


def cmd_scrape(args):
    if apply_common(args) is None:
        return 1
    print("\ncompany: %s | %s | name, location, title, experience, About\n"
          % (COMPANY, "India only" if INDIA_ONLY else "worldwide"))

    start_browser(headless=args.headless)
    if not logged_in():
        print("Not signed in. Run:  python linkedin_win.py login")
        shot("not_logged_in")
        stop_browser()
        return 1
    print("Session OK.")
    try:
        if args.skip_search and os.path.exists(INDEX_JSON):
            with open(INDEX_JSON, encoding="utf-8") as f:
                index = json.load(f)
            print("reusing the saved index of %d people" % len(index))
        else:
            index = collect_people(pages=args.pages)
        if index:
            run_profiles(index, limit=args.limit)
    except Blocked as e:
        print("\nBLOCKED during search: %s" % e)
        print(BLOCK_HELP % (len(already_done()), PROFILE_DIR))
    finally:
        stop_browser()
    export()
    return 0


def cmd_export(args):
    if apply_common(args) is None:
        return 1
    export()
    return 0


def cmd_reparse(args):
    """Re-derive every field from the archived page text, with no network access.

    This is how a parser fix reaches data already collected: the raw text of all three
    pages is kept per person, so experience and About are both rebuilt offline.
    """
    if apply_common(args) is None:
        return 1
    records = load_records()
    if not records:
        print("Nothing collected yet in " + OUT_DIR)
        return 1

    for r in records:
        r["company_target"] = COMPANY
        if r.get("experience_text"):
            r["experience_all"] = parse_experience_text(r["experience_text"])
        elif r.get("experience") and not r.get("experience_all"):
            r["experience_all"] = r["experience"]
        if r.get("profile_text"):
            r["about"] = scrape_about_text(r["profile_text"]) or r.get("about", "")
        derive(r)

    with open(JSONL, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("reparsed %d profiles" % len(records))
    export()
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--company", default=None,
                       help="company name (you are asked for it if omitted)")
        p.add_argument("--worldwide", action="store_true", help="do not restrict to India")
        p.add_argument("--fast", action="store_true",
                       help="shorter delays; raises the chance of being rate-limited")
        return p

    p = common(sub.add_parser("redo-incomplete",
                              help="refetch profiles whose page never fully rendered"))
    p.set_defaults(func=cmd_redo_incomplete)

    p = sub.add_parser("reset-session",
                       help="delete the saved Chrome session (fixes a sign-in loop)")
    p.set_defaults(func=cmd_reset_session)

    p = sub.add_parser("login", help="open Chrome and wait for you to sign in")
    p.add_argument("--wait", type=int, default=10, help="minutes to wait (default 10)")
    p.set_defaults(func=cmd_login)

    p = common(sub.add_parser("scrape", help="collect search results, then each profile"))
    p.add_argument("--pages", type=int, default=None, help="search pages per role term")
    p.add_argument("--limit", type=int, default=None, help="max profiles this run")
    p.add_argument("--headless", action="store_true", help="hide the browser window")
    p.add_argument("--skip-search", action="store_true",
                   help="reuse the saved index instead of searching again")
    p.set_defaults(func=cmd_scrape)

    p = common(sub.add_parser("export", help="write csv/json from collected data"))
    p.set_defaults(func=cmd_export)

    p = common(sub.add_parser("reparse", help="rebuild fields from archived text, then export"))
    p.set_defaults(func=cmd_reparse)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
