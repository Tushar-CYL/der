"""LinkedIn people scraper - any company, India only, posts from the last N months.

    python linkedin_win.py login                 # sign in once, session is saved
    python linkedin_win.py scrape                # asks which company, then runs
    python linkedin_win.py scrape --company Tesco --months 3
    python linkedin_win.py export                # rebuild csv/json from collected data
    python linkedin_win.py reparse               # re-derive fields offline, then export

Data lands in linkedin_out\\<company>\\ so several companies can be kept side by side.
Everything resumes: a person already collected is never fetched twice.
"""

import argparse
import csv
import datetime as dt
import json
import os
import random
import re
import shutil
import sys
import time
import traceback
from urllib.parse import quote_plus

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# ---------------------------------------------------------------- config

ROLE_TERMS = ["manager", "senior manager", "director", "partner"]

PAGES_PER_QUERY = 10
MAX_PROFILES = 500

POST_MONTHS = 3            # only keep posts newer than this many months
INDIA_ONLY = True
INDIA_GEO_URN = "102713980"   # LinkedIn's geo id for India, used as a search facet

SCRAPE_ABOUT = True
SCRAPE_EXPERIENCE = True
SCRAPE_POSTS = True

# the activity feed is infinite-scroll; stop once posts are older than the window
POSTS_MAX_SCROLLS = 30
POSTS_SCROLL_PAUSE = 1.1

# Pacing. LinkedIn rate-limits on requests per session, and the activity feed is the
# most expensive page there is: every scroll fires its own API calls. Going too fast
# earns an authwall after roughly 20 profiles, so these are deliberately unhurried.
# --fast halves them, for a throwaway account or a short run.
MIN_DELAY, MAX_DELAY = 6.0, 15.0
FAST_DELAY = (1.2, 2.6)

# A real person does not click every 3 seconds for an hour without pause. These breaks,
# and the wide random spread above, are what stop the traffic looking like a metronome.
COOLDOWN_EVERY = 12
COOLDOWN_SECS = 240
# every so often, a much longer break, as if the person walked away
LONG_BREAK_EVERY = 45
LONG_BREAK_SECS = 900
PAGE_TIMEOUT = 30

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_OUT = os.path.join(HERE, "linkedin_out")
PROFILE_DIR = os.path.join(HERE, ".chrome_linkedin_profile")

# set by set_company()
COMPANY = ""
OUT_DIR = ROOT_OUT
TEXT_DIR = os.path.join(ROOT_OUT, "text")
JSONL = os.path.join(ROOT_OUT, "profiles.jsonl")
INDEX_JSON = os.path.join(ROOT_OUT, "people_index.json")
STATE_JSON = os.path.join(ROOT_OUT, "state.json")

driver = None
TODAY = dt.date.today()


class Blocked(Exception):
    """LinkedIn bounced us to a login, authwall or security checkpoint.

    Raised instead of recorded, because continuing after a block is actively harmful: it
    writes a run of empty records, marks those people as done so a resume skips them, and
    keeps hammering an endpoint that has already said no.
    """


def company_slug(name):
    return re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_") or "company"


def set_company(name):
    """Point every path at linkedin_out\\<company>\\, creating it if needed."""
    global COMPANY, OUT_DIR, TEXT_DIR, JSONL, INDEX_JSON, STATE_JSON
    COMPANY = (name or "").strip()
    OUT_DIR = os.path.join(ROOT_OUT, company_slug(COMPANY))
    TEXT_DIR = os.path.join(OUT_DIR, "text")
    JSONL = os.path.join(OUT_DIR, "profiles.jsonl")
    INDEX_JSON = os.path.join(OUT_DIR, "people_index.json")
    STATE_JSON = os.path.join(OUT_DIR, "state.json")
    os.makedirs(TEXT_DIR, exist_ok=True)
    adopt_legacy_data()
    with open(STATE_JSON, "w", encoding="utf-8") as f:
        json.dump({"company": COMPANY, "months": POST_MONTHS,
                   "updated": TODAY.isoformat()}, f, indent=2)


def adopt_legacy_data():
    """Earlier runs wrote straight into linkedin_out\\ with no company folder.

    Those files are Tesco data, so move them into the Tesco folder once, which keeps
    the 72 already-collected profiles and lets the scrape resume instead of restart.
    """
    legacy = os.path.join(ROOT_OUT, "profiles.jsonl")
    if company_slug(COMPANY) != "tesco" or not os.path.exists(legacy):
        return
    if os.path.exists(JSONL):
        return
    for name in ("profiles.jsonl", "people_index.json"):
        src = os.path.join(ROOT_OUT, name)
        if os.path.exists(src):
            shutil.move(src, os.path.join(OUT_DIR, name))
    src_text = os.path.join(ROOT_OUT, "text")
    if os.path.isdir(src_text):
        for fn in os.listdir(src_text):
            dst = os.path.join(TEXT_DIR, fn)
            if not os.path.exists(dst):
                shutil.move(os.path.join(src_text, fn), dst)
        try:
            os.rmdir(src_text)
        except OSError:
            pass
    print("moved earlier Tesco data into " + OUT_DIR)


def load_state():
    for path in (STATE_JSON, os.path.join(ROOT_OUT, "state.json")):
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    return {}

# ---------------------------------------------------------------- browser


def start_browser(headless=False, images=False):
    global driver
    os.makedirs(PROFILE_DIR, exist_ok=True)

    opts = Options()
    opts.add_argument("--user-data-dir=" + PROFILE_DIR)
    opts.add_argument("--profile-directory=Default")
    opts.add_argument("--window-size=1600,1000")
    opts.add_argument("--lang=en-GB,en")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    # Images are never parsed, and blocking them is the single biggest speed win - but
    # a CAPTCHA and a security-check photo are images too, so sign-in must load them or
    # the challenge is invisible and impossible to answer.
    opts.add_experimental_option("prefs", {
        "profile.managed_default_content_settings.images": 1 if images else 2,
        "profile.default_content_setting_values.notifications": 2,
    })
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    if headless:
        opts.add_argument("--headless=new")

    d = webdriver.Chrome(options=opts)
    d.set_page_load_timeout(PAGE_TIMEOUT)
    d.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
    })
    driver = d
    return d


def stop_browser():
    global driver
    try:
        if driver:
            driver.quit()
    except Exception:
        pass
    driver = None


# Signed-out pages carry a .global-nav too, so nav presence proves nothing. Require a
# member-only element AND a URL that is not a login/challenge page.
SIGNED_OUT_URL_RE = re.compile(r"/(login|signup|checkpoint|authwall|uas/)", re.I)
# LinkedIn renames CSS classes constantly, so match on member-only *text* instead.
SIGNED_IN_MARKERS = ("Start a post", "Add to your feed", "Profile viewers")


def logged_in(verbose=False):
    try:
        driver.get("https://www.linkedin.com/feed/")
    except TimeoutException:
        pass
    time.sleep(3)
    url = driver.current_url
    if SIGNED_OUT_URL_RE.search(url):
        if verbose:
            print("   not signed in - sitting on %s" % url[:90])
        return False
    src = driver.page_source
    hits = [m for m in SIGNED_IN_MARKERS if m in src]
    ok = "/feed" in url and bool(hits)
    if verbose:
        print("   url=%s | markers=%s -> %s"
              % (url[:60], hits or "none", "signed in" if ok else "NOT signed in"))
    return ok


def shot(label):
    path = os.path.join(TEXT_DIR, re.sub(r"[^A-Za-z0-9_.-]", "_", label) + ".png")
    try:
        driver.save_screenshot(path)
        print("   screenshot -> " + path)
    except Exception:
        pass

# ---------------------------------------------------------------- helpers


def human_pause():
    # A flat uniform delay is itself a signature. Most human gaps are short, with an
    # occasional long one, so the short end is weighted and a tail is added now and then.
    d = random.uniform(MIN_DELAY, MAX_DELAY)
    if random.random() < 0.15:
        d += random.uniform(5, 20)
    time.sleep(d)


def goto(url, wait_css=None, timeout=20, strict=True):
    human_pause()
    try:
        driver.get(url)
    except TimeoutException:
        pass
    if wait_css:
        try:
            WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, wait_css)))
        except TimeoutException:
            pass
    else:
        time.sleep(1.5)
    if strict:
        try:
            here = driver.current_url
        except WebDriverException:
            raise Blocked("the browser window was closed")
        if SIGNED_OUT_URL_RE.search(here):
            raise Blocked("bounced to " + here[:120])
    return driver.page_source


def scroll_page(times=4, pause=1.0):
    last = 0
    for _ in range(times):
        # vary both the distance and the dwell: real scrolling is not uniform
        driver.execute_script("window.scrollBy(0, document.body.scrollHeight*%.2f);"
                              % random.uniform(0.55, 0.9))
        time.sleep(pause * random.uniform(0.7, 1.6))
        h = driver.execute_script("return document.body.scrollHeight")
        if h == last:
            break
        last = h
    driver.execute_script("window.scrollTo(0, 0);")


# Clicks every "see more" / "...more" toggle. Matched on button TEXT and aria-label, never
# on class names, because LinkedIn's classes are hashed and change on every deploy.
# Without this, long posts and About sections stay truncated at "...more".
EXPAND_JS = r"""
// Click every "...more" toggle so long text is captured in full.
//
// Most of these toggles sit INSIDE an <a> that links to the post, so a plain click
// navigates away - that is how the profile page was being replaced by a feed update,
// taking the About section with it. A capture-phase listener cancels the link's default
// navigation while still letting the button's own expand handler run.
var n = 0;
var root = document.querySelector('main') || document.body;
var block = function (e) {
  var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
  if (a) { e.preventDefault(); }
};
document.addEventListener('click', block, true);
try {
  root.querySelectorAll('button').forEach(function (b) {
    if (b.closest('nav') || b.closest('header')) { return; }
    // A toggle inside an <a> cannot be clicked safely: LinkedIn's router navigates
    // programmatically, so preventDefault does not stop it. Those are the activity
    // preview cards, whose full text we get from the activity page anyway.
    if (b.closest('a')) { return; }
    var t = (b.innerText || '').replace(/\s+/g, ' ').trim();
    var al = (b.getAttribute('aria-label') || '').toLowerCase();
    // the ellipsis form only: a bare "More" is the profile's action menu, not an expander
    var isMore = /\u2026\s*more$/i.test(t) || /^see more$/i.test(t);
    if (isMore || al.indexOf('see more') >= 0
        || al.indexOf('show more') >= 0 || al.indexOf('expand post') >= 0) {
      try { b.click(); n++; } catch (e) {}
    }
  });
} finally {
  document.removeEventListener('click', block, true);
}
return n;
"""


def expand_show_more(rounds=2):
    total = 0
    for _ in range(rounds):
        try:
            n = driver.execute_script(EXPAND_JS) or 0
        except WebDriverException:
            break
        total += n
        if not n:
            break
        time.sleep(0.6)
    return total


def page_text():
    # visible text of the page, which is what we archive instead of raw HTML
    soup = BeautifulSoup(driver.page_source, "lxml")
    for junk in soup(["script", "style", "noscript"]):
        junk.decompose()
    main = soup.find("main") or soup
    return re.sub(r"\n{3,}", "\n\n", main.get_text("\n", strip=True))


def dump_text(tag, text=None):
    tag = re.sub(r"[^A-Za-z0-9_.-]", "_", tag)[:80]
    path = os.path.join(TEXT_DIR, tag + ".txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text if text is not None else page_text())
    return path


def slug_of(url):
    m = re.search(r"/in/([^/?#]+)", url or "")
    return m.group(1) if m else ""


def p_blocks(node):
    out = []
    for p in node.find_all("p"):
        t = re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
        if t and t not in out:
            out.append(t)
    return out

# ---------------------------------------------------------------- India filter

# "Greater Bengaluru Area" and the like never contain the word India, so match cities too.
INDIA_CITY_RE = re.compile(
    r"\b(bengaluru|bangalore|mumbai|bombay|delhi|new delhi|noida|gurgaon|gurugram|"
    r"hyderabad|secunderabad|chennai|madras|pune|kolkata|calcutta|ahmedabad|jaipur|"
    r"chandigarh|lucknow|kochi|cochin|coimbatore|indore|bhopal|nagpur|surat|vadodara|"
    r"visakhapatnam|vizag|thiruvananthapuram|trivandrum|mysuru|mysore|mangaluru|"
    r"mangalore|nashik|rajkot|patna|bhubaneswar|guwahati|dehradun|ludhiana|amritsar|"
    r"faridabad|ghaziabad|thane|navi mumbai|goa|karnataka|maharashtra|telangana|"
    r"tamil nadu|kerala|gujarat|haryana|punjab|rajasthan|uttar pradesh|west bengal|"
    r"andhra pradesh|madhya pradesh|odisha|bihar|assam|jharkhand|chhattisgarh|"
    r"uttarakhand|himachal)\b", re.I)
NOT_INDIA_RE = re.compile(r"\b(indiana|indianapolis)\b", re.I)


def is_india(location):
    loc = (location or "").strip()
    if not loc:
        return False
    if NOT_INDIA_RE.search(loc):
        return False
    return bool(re.search(r"\bindia\b", loc, re.I)) or bool(INDIA_CITY_RE.search(loc))

# ---------------------------------------------------------------- search

JUNK_NAMES = {"", "linkedin member", "status is offline", "status is reachable"}
IN_RE = re.compile(r"/in/")
# trailing connection degree on the name line, e.g. "Jane Doe - 2nd"
DEGREE_RE = re.compile(r"[·•∙|]\s*(1st|2nd|3rd\+?|Following|Connect)\s*$", re.I)


def search_queries():
    return ["%s %s" % (COMPANY, term) for term in ROLE_TERMS]


def search_url(query, page=1):
    url = "https://www.linkedin.com/search/results/people/?keywords=" + quote_plus(query)
    if INDIA_ONLY:
        url += "&geoUrn=%5B%22" + INDIA_GEO_URN + "%22%5D"
    if page > 1:
        url += "&page=" + str(page)
    return url


def parse_search_results(html):
    # LinkedIn ships hashed CSS classes (l4jkxn, ...) that change every deploy, so match on
    # structure: a result card is an /in/ anchor with no /in/ anchor above it. Mutual-connection
    # links are always nested inside a card anchor, which is what excludes them.
    soup = BeautifulSoup(html, "lxml")
    main = soup.find("main") or soup
    people, seen = [], set()

    for a in main.select('a[href*="/in/"]'):
        if a.find_parent("a", href=IN_RE):
            continue
        slug = slug_of(a.get("href", ""))
        if not slug or slug in seen:
            continue

        blocks = []
        for p in a.find_all("p"):
            t = re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
            if t and t not in blocks:
                blocks.append(t)
        if not blocks:
            continue

        name = DEGREE_RE.sub("", blocks[0]).strip(" ·•|")
        if len(name) < 2 or name.lower() in JUNK_NAMES:
            continue

        rest = blocks[1:]
        mutual = next((t for t in rest if "mutual connection" in t.lower()), "")
        rest = [t for t in rest if t != mutual]
        # LinkedIn's AI blurb is an extra long paragraph after headline + location
        summary = ""
        if len(rest) > 2:
            summary = max(rest[2:], key=len)
            rest = rest[:2]

        seen.add(slug)
        people.append({
            "slug": slug,
            "name": name,
            "headline": rest[0] if rest else "",
            "location": rest[1] if len(rest) > 1 else "",
            "ai_summary": summary,
            "mutual_connections": mutual,
            "profile_url": "https://www.linkedin.com/in/" + slug + "/",
        })
    return people


def collect_people(pages=None):
    pages = pages if pages is not None else PAGES_PER_QUERY
    found = {}

    if os.path.exists(INDEX_JSON):
        with open(INDEX_JSON, encoding="utf-8") as f:
            for r in json.load(f):
                found[r["slug"]] = r
        print("%d people already in the index" % len(found))

    skipped = 0
    for q in search_queries():
        print("\n=== %s ===" % q)
        for page in range(1, pages + 1):
            goto(search_url(q, page), wait_css="main", strict=False)
            scroll_page(times=3, pause=0.8)

            if "/search/results/people" not in driver.current_url:
                print("  page %2d: redirected to %s - rate-limited or signed out. Stopping query."
                      % (page, driver.current_url))
                dump_text("search_redirect_%s_%d" % (company_slug(q), page))
                shot("search_redirect_%s_%d" % (company_slug(q), page))
                break

            rows = parse_search_results(driver.page_source)
            new = 0
            for r in rows:
                if INDIA_ONLY and not is_india(r.get("location")):
                    skipped += 1
                    continue
                if r["slug"] not in found:
                    r["found_via"] = q
                    found[r["slug"]] = r
                    new += 1
            print("  page %2d: %2d results (%2d new india, %3d total)"
                  % (page, len(rows), new, len(found)))

            if not rows:
                dump_text("search_empty_%s_%d" % (company_slug(q), page))
                print("  nothing parsed - end of results, or selectors need a look.")
                break

    with open(INDEX_JSON, "w", encoding="utf-8") as f:
        json.dump(list(found.values()), f, indent=2, ensure_ascii=False)
    print("\n%d people in index (%d non-India skipped) -> %s"
          % (len(found), skipped, INDEX_JSON))
    return list(found.values())

# ---------------------------------------------------------------- profile header

# throwaway fragments in the profile header: degree badges, counters, action buttons
JUNK_P_RE = re.compile(
    r"^(\W*(1st|2nd|3rd\+?)\W*|Contact info|connections?|followers?|[\d,]+\+?|"
    r"Message|Connect|Follow|More|Save in Sales Navigator|\W+)$", re.I)


def scrape_top_card(soup):
    # the profile name is an <h2>; these pages carry no <h1> at all
    main = soup.find("main") or soup
    out = {"name_profile": "", "headline_profile": "", "location_profile": ""}

    h2 = main.find("h2")
    if h2:
        out["name_profile"] = h2.get_text(" ", strip=True)

    raw = p_blocks(main)[:16]
    clean = [t for t in raw if not JUNK_P_RE.match(t)]
    if clean:
        out["headline_profile"] = clean[0]
    if "Contact info" in raw:
        before = [t for t in raw[:raw.index("Contact info")] if not JUNK_P_RE.match(t)]
        if len(before) >= 2:
            out["location_profile"] = before[-1]
    elif len(clean) > 2:
        out["location_profile"] = clean[2]
    return out


# Section order on a profile is: top card, About, Activity, Experience, ...
# so the About body is whatever sits between the About heading and the next heading.
ABOUT_STOP_RE = re.compile(
    r"^(Activity|Experience|Education|Licenses|Skills|Recommendations|Interests|"
    r"Accomplishments|Featured|Top skills|Highlights|Services|Courses|Projects|"
    r"Publications|Languages|Volunteering|Honors|Organizations|People also viewed|"
    r"Show all|Followers|Following|Accessibility|Talent Solutions|Community Guidelines|"
    r"Careers|Marketing Solutions|Privacy|Ad Choices|Advertising|Sales Solutions|"
    r"Mobile|Small Business|Safety Center|Questions|Manage your account)\b", re.I)


def scrape_about_text(profile_text):
    """Pull the About paragraph out of the page text.

    Done on text rather than the DOM because the About heading is the only stable
    landmark - the section wrapper's id and classes are generated per deploy. LinkedIn's
    page footer also contains a bare 'About' link, so a candidate only counts when real
    prose follows it, and the longest such candidate wins.
    """
    lines = [l.strip() for l in (profile_text or "").split("\n") if l.strip()]
    best = ""
    for i, line in enumerate(lines):
        if line.lower() != "about":
            continue
        body = []
        for nxt in lines[i + 1:i + 60]:
            if ABOUT_STOP_RE.match(nxt) or nxt.lower() == "about":
                break
            if nxt.lower() in ("…", "more", "see more", "…more", "follow",
                               "message", "·", "top skills"):
                continue
            if len(nxt) < 3:
                continue
            body.append(nxt)
        text = "\n".join(body).strip()
        if len(text) > len(best) and len(text) > 40:
            best = text
    return best


def scrape_about_dom(soup):
    main = soup.find("main") or soup
    for h in main.find_all(["h2", "h3"]):
        if h.get_text(strip=True).lower() == "about":
            sec = h.find_parent("section") or h.parent
            blocks = [t for t in p_blocks(sec) if t.lower() != "about"]
            if blocks:
                return max(blocks, key=len)
    return ""

# ---------------------------------------------------------------- experience

EMP_TYPE_RE = re.compile(
    r"\b(Full-time|Part-time|Contract|Internship|Freelance|Self-employed|Seasonal|"
    r"Apprenticeship|Permanent|Temporary)\b", re.I)
DATE_LINE_RE = re.compile(
    r"^((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?(19|20)\d{2}\s*[-–]\s*"
    r"((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?((19|20)\d{2}|Present)", re.I)
MIDDOT = "·"
# second line of a company group header: "Full-time - 6 yrs 5 mos", or just "4 yrs"
DURATION_RE = re.compile(
    r"^(?:(?:Full-time|Part-time|Contract|Internship|Freelance|Self-employed|Seasonal|"
    r"Apprenticeship|Permanent|Temporary)\s*[·-]?\s*)?\d+\s*(?:yr|yrs|mo|mos)\b", re.I)
NOISE_RE = re.compile(r"^(Ad Options|Why am I seeing this ad|Don.t want to see this|"
                      r"Experience|More profiles|People you may know|Show all)", re.I)


MONTH_NUM = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun",
     "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}
RANGE_RE = re.compile(
    r"^(?:([A-Za-z]{3,9})\s+)?((?:19|20)\d{2})\s*[-–]\s*"
    r"(?:(?:([A-Za-z]{3,9})\s+)?((?:19|20)\d{2})|(Present))", re.I)


def parse_date_range(dates):
    """'Jan 2019 - Present' -> (start, end) as absolute month numbers."""
    m = RANGE_RE.match((dates or "").strip())
    if not m:
        return None
    sm, sy, em, ey, present = m.groups()
    start = int(sy) * 12 + MONTH_NUM.get((sm or "jan")[:3].lower(), 1)
    if present:
        end = TODAY.year * 12 + TODAY.month
    else:
        end = int(ey) * 12 + MONTH_NUM.get((em or "dec")[:3].lower(), 12)
    if end < start:
        start, end = end, start
    return start, end


DUR_PARTS_RE = re.compile(r"(\d+)\s*(yrs?|mos?)\b", re.I)


def duration_months(text):
    """'5 yrs 7 mos' -> 67. Reads the duration LinkedIn itself prints."""
    total = 0
    for n, unit in DUR_PARTS_RE.findall(text or ""):
        total += int(n) * (12 if unit.lower().startswith("yr") else 1)
    return total


def parse_experience_text(text):
    """Parse the experience list from page TEXT, not the DOM.

    LinkedIn's CSS classes are hashed and regenerated per deploy, so every role is
    anchored on its date line instead. Three layouts occur around that line:

      A grouped    "Tesco Bengaluru" / "5 yrs 7 mos"          <- company header
                   "Senior Manager" / ["Full-time"] / "May 2016 - Nov 2017"
      B ungrouped  "Senior Manager" / "Tesco Bengaluru - Full-time" / dates
      C bare       "Team Manager" / "Dell" / dates

    A group header is a line followed by a bare duration. The group closes once its roles
    have used up the header's total, which is what stops a later employer's roles from
    being credited to it: a profile lists several groups one after another and nothing
    else marks where one ends.
    """
    lines = [l.strip() for l in (text or "").split("\n") if l.strip()]
    date_idx = [i for i, l in enumerate(lines) if DATE_LINE_RE.match(l)]
    rows = []
    group, group_total, group_used = "", 0, 0

    for i, line in enumerate(lines):
        nxt = lines[i + 1] if i + 1 < len(lines) else ""

        # layout A header: company name on one line, its total duration on the next.
        # Requiring that duration is what keeps a role title followed by a bare
        # "Full-time" from being mistaken for a new company header.
        if (nxt and DURATION_RE.match(nxt) and not DATE_LINE_RE.match(nxt)
                and not DATE_LINE_RE.match(line) and not NOISE_RE.match(line)
                and not EMP_TYPE_RE.match(line)):
            group, group_total, group_used = line, duration_months(nxt), 0
            continue

        if not DATE_LINE_RE.match(line):
            continue

        prev = lines[i - 1] if i >= 1 else ""
        prev2 = lines[i - 2] if i >= 2 else ""
        prev3 = lines[i - 3] if i >= 3 else ""

        if MIDDOT in prev and EMP_TYPE_RE.search(prev) and not EMP_TYPE_RE.match(prev):
            company, title = prev.split(MIDDOT)[0].strip(), prev2   # layout B
            group, group_total, group_used = "", 0, 0
        elif group:
            # layout A; a bare "Full-time" sits between the title and the dates
            company = group
            title = prev2 if EMP_TYPE_RE.match(prev) else prev
            if EMP_TYPE_RE.match(prev) and EMP_TYPE_RE.match(prev2 or ""):
                title = prev3
        else:
            company, title = prev, prev2                            # layout C

        nxt_date = next((d for d in date_idx if d > i), len(lines))
        tail = [t for t in lines[i + 1:max(i + 1, nxt_date - 1)] if not NOISE_RE.match(t)]
        location = ""
        if tail and not DATE_LINE_RE.match(tail[0]) and len(tail[0]) <= 90:
            location = tail[0]
            tail = tail[1:]

        title = (title or "").strip()
        if not title or NOISE_RE.match(title) or title == company:
            continue
        rows.append({
            "title": title,
            "company": company.strip(),
            "dates": line,
            "location": location,
            "description": " ".join(t for t in tail if t not in (company, title)).strip(),
            "raw": " | ".join(lines[max(0, i - 3):i + 2]),
        })

        # close the group once its roles account for the header's total
        if group and group_total:
            span = parse_date_range(line)
            group_used += duration_months(line) or (span[1] - span[0] + 1 if span else 0)
            if group_used >= group_total:
                group, group_total, group_used = "", 0, 0
    return rows


# legal suffixes and group words that differ between how people type a company name
COMPANY_NOISE_RE = re.compile(
    r"\b(ltd|limited|plc|inc|incorporated|llc|llp|pvt|private|corp|corporation|co|"
    r"company|group|holdings|holding|technologies|technology|services|solutions|"
    r"global|international|india|bengaluru|bangalore|gcc|hsc)\b", re.I)


def norm_company(name):
    s = re.sub(r"[^a-z0-9 ]+", " ", (name or "").lower())
    s = COMPANY_NOISE_RE.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def company_matches(row_company, target=None):
    """True when an experience row belongs to the company we asked for.

    Compared on normalised tokens so "Tesco Bengaluru", "Tesco PLC" and "Tesco" all match,
    while "Tescore" or an unrelated employer does not. Token equality is required, never a
    substring, which is what keeps "Tesco" from matching "Tescore Analytics".
    """
    target = norm_company(target if target is not None else COMPANY)
    if not target:
        return True
    row = norm_company(row_company)
    if not row:
        return False
    t_tokens, r_tokens = target.split(), set(row.split())
    return bool(t_tokens) and all(t in r_tokens for t in t_tokens)


def months_to_text(months):
    y, m = divmod(max(0, int(months)), 12)
    parts = []
    if y:
        parts.append("%d yr%s" % (y, "s" if y != 1 else ""))
    if m or not y:
        parts.append("%d mo%s" % (m, "s" if m != 1 else ""))
    return " ".join(parts)


def tenure_months(rows):
    """Total months at the company, merging overlapping roles so none is double counted."""
    spans = sorted(s for s in (parse_date_range(r.get("dates")) for r in rows) if s)
    if not spans:
        return 0
    merged = [list(spans[0])]
    for start, end in spans[1:]:
        if start <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    # the end month counts as worked, so a Jan-Jan span is one month
    return sum(e - s + 1 for s, e in merged)


def company_experience(rows, target=None):
    """The rows for the target company only, newest first, plus total tenure in months."""
    hits = [dict(r) for r in (rows or []) if company_matches(r.get("company"), target)]
    for r in hits:
        span = parse_date_range(r.get("dates"))
        r["duration"] = months_to_text(span[1] - span[0] + 1) if span else ""
        r["_end"] = span[1] if span else 0
    hits.sort(key=lambda r: r.get("_end", 0), reverse=True)
    for r in hits:
        r.pop("_end", None)
    return hits, tenure_months(hits)


def scrape_experience(slug):
    goto("https://www.linkedin.com/in/" + slug + "/details/experience/", wait_css="main")
    scroll_page(times=3, pause=0.8)
    expand_show_more()
    txt = page_text()
    return parse_experience_text(txt), txt

# ---------------------------------------------------------------- posts

# LinkedIn stamps activity either relatively ("3d", "2w", "5mo") or absolutely
# ("Aug 17", "Aug 17, 2025"), and may append " - Edited".
REL_TS_RE = re.compile(r"^(\d+)\s*(s|m|h|d|w|mo|yr|y)\b", re.I)
ABS_TS_RE = re.compile(
    r"^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+(\d{1,2})"
    r"(?:,?\s*((?:19|20)\d{2}))?\s*$", re.I)
EDITED_RE = re.compile(r"\s*[•·]\s*Edited\s*$", re.I)
UNIT_DAYS = {"s": 0, "m": 0, "h": 0, "d": 1, "w": 7, "mo": 30, "yr": 365, "y": 365}


def parse_post_date(stamp):
    """-> (iso date or '', days ago or None). An unreadable stamp returns ('', None)."""
    s = EDITED_RE.sub("", (stamp or "").strip()).strip()
    m = REL_TS_RE.match(s)
    if m:
        n, unit = int(m.group(1)), m.group(2).lower()
        days = n * UNIT_DAYS.get(unit, 0)
        return (TODAY - dt.timedelta(days=days)).isoformat(), days
    m = ABS_TS_RE.match(s)
    if m:
        mon, day, year = m.group(1)[:3].lower(), int(m.group(2)), m.group(3)
        try:
            if year:
                d = dt.date(int(year), MONTH_NUM[mon], day)
            else:
                # no year shown means inside the last 12 months: take the most recent
                # occurrence of that day which is not in the future
                d = dt.date(TODAY.year, MONTH_NUM[mon], day)
                if d > TODAY:
                    d = dt.date(TODAY.year - 1, MONTH_NUM[mon], day)
        except ValueError:
            return "", None
        return d.isoformat(), (TODAY - d).days
    return "", None


def is_timestamp(line):
    s = EDITED_RE.sub("", (line or "").strip()).strip()
    return bool(REL_TS_RE.match(s)) or bool(ABS_TS_RE.match(s))


REACT_RE = re.compile(r"^([\d,]+)\s*(reaction|comment|repost)s?\b", re.I)
NUM_ONLY_RE = re.compile(r"^([\d,]+)$")
COUNT_WORD_RE = re.compile(r"^(reaction|comment|repost)s?$", re.I)
# "and 149 others reacted" / "and 149 others"
OTHERS_RE = re.compile(r"^others?\b", re.I)
POST_CHROME_RE = re.compile(
    r"^(Like|Comment|Repost|Send|Follow|Following|…|more|see more|…more|"
    r"[•·]|Load more comments|Show more|Author|Translate|See translation|"
    r"Activate to view larger image|Play|Pause|Mute|Unmute|\d+:\d+|"
    r"feed update|View profile|Connect)$", re.I)
# "Hemanth reposted this", "X commented on this", "Y likes this"
RELATION_RE = re.compile(
    r"(reposted this|shared this|commented on this|replied to this|likes this|"
    r"loves this|celebrates this|supports this|finds this insightful|"
    r"is celebrating this|curious about this)", re.I)


def parse_posts_text(activity_text, owner_name=""):
    """Parse the activity feed from page text.

    Keyed on the 'Feed post' heading LinkedIn puts before every entry. The entire body is
    kept: the earlier DOM-based version took only the single longest paragraph, which
    silently truncated every multi-paragraph post to one line.
    """
    lines = [l.strip() for l in (activity_text or "").split("\n") if l.strip()]
    marks = [i for i, l in enumerate(lines) if l.lower() in ("feed post", "post")]
    out, seen = [], set()

    for n, start in enumerate(marks):
        end = marks[n + 1] if n + 1 < len(marks) else len(lines)
        block = lines[start + 1:end]
        if not block:
            continue

        # who did what: the owner's line, then optionally "reposted this" + original author
        kind, original_author = "post", ""
        rel = next((j for j, l in enumerate(block[:4]) if RELATION_RE.search(l)), None)
        if rel is not None:
            verb = RELATION_RE.search(block[rel]).group(1).lower()
            if "repost" in verb or "shared" in verb:
                kind = "repost"
            elif "comment" in verb or "replied" in verb:
                kind = "comment"
            else:
                kind = "reaction"
            after = [l for l in block[rel + 1:rel + 3] if not POST_CHROME_RE.match(l)]
            if after:
                original_author = after[0]

        ts_at = next((j for j, l in enumerate(block) if is_timestamp(l)), None)
        if ts_at is None:
            continue              # no timestamp => page furniture, not a real entry
        posted_raw = block[ts_at]
        iso, days = parse_post_date(posted_raw)

        body, counts = [], {"reaction": 0, "comment": 0, "repost": 0}
        tail = block[ts_at + 1:]
        j = 0
        while j < len(tail):
            line = tail[j]
            nxt = tail[j + 1] if j + 1 < len(tail) else ""
            num = NUM_ONLY_RE.match(line)

            # LinkedIn splits engagement over two lines: "724" then "reactions".
            # It also writes social proof as: "Astik Raj" / "and" / "149" / "others
            # reacted", which means 149 others plus the one named person.
            if num and COUNT_WORD_RE.match(nxt):
                val = int(num.group(1).replace(",", ""))
                kind = COUNT_WORD_RE.match(nxt).group(1).lower().rstrip("s")
                counts[kind] = max(counts[kind], val)
                j += 2
                continue
            if num and OTHERS_RE.match(nxt):
                val = int(num.group(1).replace(",", "")) + 1
                counts["reaction"] = max(counts["reaction"], val)
                j += 2
                continue

            m = REACT_RE.match(line)              # older one-line form
            if m:
                kind = m.group(2).lower()
                counts[kind] = max(counts[kind], int(m.group(1).replace(",", "")))
                j += 1
                continue

            j += 1
            if (POST_CHROME_RE.match(line) or COUNT_WORD_RE.match(line)
                    or OTHERS_RE.match(line) or num or is_timestamp(line)
                    or line in (owner_name, original_author)):
                continue
            body.append(line)

        reactions = counts["reaction"]
        comments = counts["comment"]
        reposts = counts["repost"]

        text = "\n".join(dict.fromkeys(body)).strip()
        # an entry left with no real body is page furniture, not something they posted
        if len(text) < 15:
            continue
        key = re.sub(r"\W+", "", text.lower())[:140]
        if key in seen:
            continue
        seen.add(key)

        out.append({
            "type": kind,
            "original_author": original_author,
            "posted_raw": posted_raw,
            "date": iso,
            "days_ago": days,
            "text": text,
            "reactions": reactions,
            "comments": comments,
            "reposts": reposts,
        })
    return out


def recent_posts(posts, months=None, kinds=("post", "repost")):
    """The entries this person published inside the window, newest first.

    An entry whose timestamp could not be read is kept rather than dropped: losing a real
    post is worse than carrying one that may be slightly outside the window.
    """
    months = POST_MONTHS if months is None else months
    cutoff = months * 31
    keep = [dict(p) for p in (posts or [])
            if p.get("type") in kinds
            and (p.get("days_ago") is None or p["days_ago"] <= cutoff)]
    keep.sort(key=lambda p: p.get("days_ago") if p.get("days_ago") is not None else 0)
    for i, p in enumerate(keep, 1):
        p["no"] = i
    return keep


def oldest_days(posts):
    seen = [p["days_ago"] for p in posts if p.get("days_ago") is not None]
    return max(seen) if seen else None


def scrape_posts(slug, name="", months=None):
    """Scroll the activity feed until it passes the window, or the feed runs out."""
    months = POST_MONTHS if months is None else months
    cutoff = months * 31
    goto("https://www.linkedin.com/in/" + slug + "/recent-activity/all/", wait_css="main")

    stall, last_h = 0, 0
    for i in range(POSTS_MAX_SCROLLS):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(POSTS_SCROLL_PAUSE * random.uniform(0.8, 1.8))
        h = driver.execute_script("return document.body.scrollHeight")
        stall = stall + 1 if h == last_h else 0
        last_h = h
        if stall >= 2:
            break                      # feed exhausted
        if i % 3 == 2:
            old = oldest_days(parse_posts_text(page_text(), name))
            if old is not None and old > cutoff:
                break                  # already past the window, no need to load more

    expand_show_more(rounds=3)          # open every "...more" before reading the text
    txt = page_text()
    return parse_posts_text(txt, name), txt

# ---------------------------------------------------------------- one person


def ensure_about(slug="", max_steps=3):
    """Return the About text, re-reading after each expand attempt.

    The section is present in the page as soon as it loads - this only exists to catch
    the case where the paragraph is still collapsed behind its "...more" toggle.
    """
    about = scrape_about_text(page_text())
    for _ in range(max_steps):
        if about or (slug and not on_profile(slug)):
            break
        if not expand_show_more(rounds=1):
            break
        time.sleep(0.4)
        about = scrape_about_text(page_text())
    return about


MIN_PROFILE_LINES = 150


def wait_rendered(slug, tries=7):
    """Wait until the profile has actually painted before its text is read.

    A profile still rendering yields a stub of ~100 lines where a finished one gives
    500+, and reading that stub loses the About section silently - it looks identical
    to a person who has none. Waiting on a landmark beats a fixed sleep, because load
    time varies with the size of the person's history and with how busy the machine is.
    """
    txt = ""
    for n in range(tries):
        txt = page_text()
        lines = [l for l in txt.split("\n") if l.strip()]
        landmarks = sum(1 for m in ("Experience", "Activity", "Education", "Skills")
                        if m in lines)
        if len(lines) >= MIN_PROFILE_LINES and landmarks >= 1:
            return txt
        if not on_profile(slug):
            return txt
        # one reload part-way through: a page that stalled on first load usually comes
        # back complete, while waiting longer on a dead render achieves nothing
        if n == 3:
            try:
                driver.get("https://www.linkedin.com/in/%s/" % slug)
                time.sleep(3)
            except WebDriverException:
                return txt
        time.sleep(1.5 + n)
        scroll_page(times=1, pause=0.6)
    return txt


def on_profile(slug):
    """Still on this person's profile page, rather than somewhere a click took us."""
    try:
        return ("/in/" + slug.lower()) in driver.current_url.lower()
    except WebDriverException:
        return False


def scrape_profile(person, months=None):
    months = POST_MONTHS if months is None else months
    slug = person["slug"]
    rec = dict(person)
    rec["company_target"] = COMPANY

    goto(person["profile_url"], wait_css="main")
    if "/in/" not in driver.current_url:
        # not a signed-out bounce (goto would have raised); a dead or renamed profile
        rec["error"] = "redirected to " + driver.current_url
        return rec

    scroll_page(times=3, pause=0.9)
    # Snapshot before any clicking. If an expand click still manages to navigate, this
    # pristine copy is what gets used, so a profile can never be recorded as some other
    # page's content.
    clean_txt = wait_rendered(slug)
    clean_html = driver.page_source

    expand_show_more()
    about = ensure_about(slug) if SCRAPE_ABOUT else ""

    if on_profile(slug):
        soup = BeautifulSoup(driver.page_source, "lxml")
        profile_txt = page_text()
    else:
        print("      (drifted off %s, using the pre-click capture)" % slug)
        soup = BeautifulSoup(clean_html, "lxml")
        profile_txt = clean_txt
        about = about or scrape_about_text(clean_txt)

    top = scrape_top_card(soup)
    if top.get("name_profile", "").lower() in ("feed post", "premium", "", "linkedin"):
        # the header did not come from a profile page; keep what search already gave us
        top = {"name_profile": person.get("name", ""),
               "headline_profile": person.get("headline", ""),
               "location_profile": person.get("location", "")}
    rec.update(top)
    rec["about"] = (about or scrape_about_text(profile_txt)
                    or scrape_about_dom(soup)) if SCRAPE_ABOUT else ""

    all_exp, exp_txt = scrape_experience(slug) if SCRAPE_EXPERIENCE else ([], "")
    all_posts, posts_txt = scrape_posts(slug, person.get("name", ""), months) \
        if SCRAPE_POSTS else ([], "")

    # archive the full visible text of all three pages, as text
    full = ("===== PROFILE =====\n" + profile_txt
            + "\n\n===== EXPERIENCE =====\n" + exp_txt
            + "\n\n===== ACTIVITY =====\n" + posts_txt)
    rec["text_file"] = dump_text(slug, full)
    rec["profile_text"] = profile_txt
    rec["experience_text"] = exp_txt
    rec["activity_text"] = posts_txt

    rec["render_ok"] = len([l for l in profile_txt.split("\n") if l.strip()]) \
        >= MIN_PROFILE_LINES
    rec["experience_all"] = all_exp
    rec["posts_all"] = all_posts
    derive(rec, months)
    return rec


def derive(rec, months=None):
    """Fill the reported fields from the raw ones. Used by the scrape and by reparse."""
    months = POST_MONTHS if months is None else months
    target = rec.get("company_target") or COMPANY
    exp, tenure = company_experience(rec.get("experience_all") or [], target)
    rec["experience"] = exp
    rec["n_experience"] = len(exp)
    rec["yoe_at_company_months"] = tenure
    rec["yoe_at_company"] = months_to_text(tenure) if tenure else ""
    rec["yoe_at_company_years"] = round(tenure / 12.0, 1) if tenure else 0.0
    rec["company_resolved"] = exp[0]["company"] if exp else ""
    if exp:
        rec["designation"] = exp[0]["title"]
        rec["designation_source"] = "experience"
    else:
        # no row matched the company, so fall back to the headline and say so, which keeps
        # the guess auditable instead of passing it off as parsed data
        rec["designation"] = rec.get("headline_profile") or rec.get("headline", "")
        rec["designation_source"] = "headline"

    rec["posts"] = recent_posts(rec.get("posts_all") or [], months)
    rec["n_posts"] = len(rec["posts"])
    rec["n_posts_all"] = len(rec.get("posts_all") or [])
    rec["location_final"] = rec.get("location_profile") or rec.get("location", "")
    rec["is_india"] = is_india(rec["location_final"])
    return rec

# ---------------------------------------------------------------- run


def load_records():
    records = []
    if os.path.exists(JSONL):
        with open(JSONL, encoding="utf-8") as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    return records


def already_done():
    return set(r.get("slug") for r in load_records() if r.get("slug"))


BLOCK_HELP = """
LinkedIn has stopped serving pages to this session. Nothing is lost - %d people are
saved and the run resumes from there.

This is a rate limit, not a bug. The activity feed is the expensive part: every scroll
fires its own API calls, so posts cost far more requests than profiles do. It usually
trips after 20-40 profiles in one sitting.

What to do:
  1. Close the script and leave LinkedIn alone for a few hours. Same day is usually
     enough; a day is safer.
  2. Open LinkedIn in your normal browser and check for a security prompt waiting for
     you. Clear it there, as a human.
  3. Then:  python linkedin_win.py scrape --limit 20
     Short runs with a pause between them get through where one long run does not.

If signing in starts looping - the page reloading every second, never settling - the
saved session is stale and Chrome keeps replaying it. Reset it:
       python linkedin_win.py reset-session
       python linkedin_win.py login
That deletes %s and signs you in fresh.
"""


def fmt_eta(seconds):
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, _ = divmod(rem, 60)
    return "%dh%02dm" % (h, m) if h else "%dm" % m


def run_profiles(index, limit=None, months=None):
    limit = limit if limit is not None else MAX_PROFILES
    months = POST_MONTHS if months is None else months
    done = already_done()
    todo = [p for p in index if p["slug"] not in done]
    if INDIA_ONLY:
        before = len(todo)
        todo = [p for p in todo if is_india(p.get("location"))]
        if before != len(todo):
            print("%d non-India people in the index skipped" % (before - len(todo)))
    if limit:
        todo = todo[:limit]

    print("\n%d already scraped | %d to go\n" % (len(done), len(todo)))
    started, fails = time.time(), 0

    with open(JSONL, "a", encoding="utf-8") as out:
        for i, person in enumerate(todo, 1):
            if i > 1 and (i - 1) % LONG_BREAK_EVERY == 0:
                nap = int(LONG_BREAK_SECS * random.uniform(0.7, 1.4))
                print("   ... long break, %d min (looks like stepping away)" % (nap // 60))
                time.sleep(nap)
            elif i > 1 and (i - 1) % COOLDOWN_EVERY == 0:
                nap = int(COOLDOWN_SECS * random.uniform(0.6, 1.5))
                print("   ... pausing %ds" % nap)
                time.sleep(nap)
            label = "[%3d/%3d] %-32s" % (i, len(todo), person["name"][:32])
            try:
                rec = scrape_profile(person, months)
                out.write(json.dumps(rec, ensure_ascii=False) + "\n")
                out.flush()
                per = (time.time() - started) / i
                if not rec.get("render_ok", True):
                    print("      (page did not fully render - run redo-incomplete later)")
                print("%s roles=%-2d %-12s posts=%-3d %3.0fs eta %s"
                      % (label, rec.get("n_experience", 0),
                         (rec.get("yoe_at_company") or "-")[:12],
                         rec.get("n_posts", 0), per,
                         fmt_eta(per * (len(todo) - i))))
                fails = 0
            except Blocked as e:
                print("%s BLOCKED: %s" % (label, e))
                print(BLOCK_HELP % (len(done) + i - 1, PROFILE_DIR))
                shot("blocked")
                break
            except KeyboardInterrupt:
                print("\nStopped. Progress is saved.")
                break
            except Exception as e:
                fails += 1
                print("%s FAILED: %s: %s" % (label, type(e).__name__, e))
                traceback.print_exc(limit=1)
                if fails >= 5:
                    print("\n5 failures in a row - stopping. Usually signed out or rate-limited.")
                    shot("run_failure")
                    break
                time.sleep(20)

    print("\nSaved to " + JSONL)

# ---------------------------------------------------------------- export


def posts_cell(posts):
    """The numbered post list the brief asks for, as one cell."""
    out = []
    for p in posts:
        head = "%d. [%s]" % (p.get("no", 0), p.get("date") or p.get("posted_raw", "?"))
        if p.get("type") == "repost":
            head += " (repost of %s)" % (p.get("original_author") or "someone")
        head += " reactions=%d comments=%d reposts=%d" % (
            p.get("reactions", 0), p.get("comments", 0), p.get("reposts", 0))
        out.append("%s\n%s" % (head, p.get("text", "")))
    return "\n\n".join(out)


def export(months=None):
    months = POST_MONTHS if months is None else months
    records = load_records()
    print("%d profiles loaded from %s" % (len(records), JSONL))
    if not records:
        print("Nothing to export yet - run the scrape first.")
        return

    for r in records:
        derive(r, months)
    if INDIA_ONLY:
        kept = [r for r in records if r.get("is_india")]
        if len(kept) != len(records):
            print("%d non-India profiles left out of the export" % (len(records) - len(kept)))
        records = kept
    records.sort(key=lambda r: (-(r.get("n_posts") or 0), r.get("name", "")))
    for i, r in enumerate(records, 1):
        r["sr_no"] = i

    # ---- the single wide table: one row per person, posts numbered in one cell
    final_cols = ["sr_no", "name", "designation", "yoe_at_company", "yoe_years",
                  "location", "description", "n_posts", "posts", "company",
                  "headline", "profile_url", "slug"]
    final_rows = [[
        r["sr_no"], r.get("name", ""), r.get("designation", ""),
        r.get("yoe_at_company", ""), r.get("yoe_at_company_years", 0),
        r.get("location_final", ""), r.get("about", ""), r.get("n_posts", 0),
        posts_cell(r.get("posts") or []),
        r.get("company_resolved") or r.get("company_target", ""),
        r.get("headline_profile") or r.get("headline", ""),
        r.get("profile_url", ""), r.get("slug", ""),
    ] for r in records]

    # ---- the same data as JSON, which keeps the posts as real objects
    payload = {
        "company": COMPANY,
        "generated": dt.datetime.now().isoformat(timespec="seconds"),
        "post_window_months": months,
        "india_only": INDIA_ONLY,
        "people_count": len(records),
        "post_count": sum(len(r.get("posts") or []) for r in records),
        "fields": {
            "sr_no": "row number, 1..n",
            "name": "person's name",
            "designation": "job title at " + (COMPANY or "the company"),
            "designation_source": "'experience' if parsed from the role, 'headline' if guessed",
            "yoe_at_company": "time at " + (COMPANY or "the company")
                              + ", overlapping roles merged",
            "location": "profile location",
            "description": "the About section of the profile",
            "experience_at_company": "roles at " + (COMPANY or "the company") + " only",
            "posts": "posts and reposts from the last %d months, newest first" % months,
        },
        "people": [{
            "sr_no": r["sr_no"],
            "name": r.get("name", ""),
            "designation": r.get("designation", ""),
            "designation_source": r.get("designation_source", ""),
            "yoe_at_company": r.get("yoe_at_company", ""),
            "yoe_at_company_years": r.get("yoe_at_company_years", 0),
            "company": r.get("company_resolved") or r.get("company_target", ""),
            "location": r.get("location_final", ""),
            "headline": r.get("headline_profile") or r.get("headline", ""),
            "description": r.get("about", ""),
            "profile_url": r.get("profile_url", ""),
            "experience_at_company": [
                dict((k, e.get(k, "")) for k in
                     ("title", "company", "dates", "duration", "location", "description"))
                for e in (r.get("experience") or [])],
            "n_posts": r.get("n_posts", 0),
            "posts": [dict((k, p.get(k)) for k in
                           ("no", "date", "posted_raw", "days_ago", "type",
                            "original_author", "text", "reactions", "comments", "reposts"))
                      for p in (r.get("posts") or [])],
        } for r in records],
    }
    jpath = os.path.join(OUT_DIR, "final.json")
    with open(jpath, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    print("final.json   %5d people, %d posts -> %s"
          % (payload["people_count"], payload["post_count"], jpath))

    # ---- supporting flat tables
    people_cols = ["sr_no", "slug", "name", "designation", "designation_source",
                   "yoe_at_company", "yoe_years", "location", "description", "n_posts",
                   "n_roles_at_company", "company", "headline", "ai_summary",
                   "mutual_connections", "found_via", "profile_url", "text_file", "error"]
    people_rows = [[r["sr_no"], r.get("slug", ""), r.get("name", ""),
                    r.get("designation", ""), r.get("designation_source", ""),
                    r.get("yoe_at_company", ""), r.get("yoe_at_company_years", 0),
                    r.get("location_final", ""), r.get("about", ""), r.get("n_posts", 0),
                    r.get("n_experience", 0),
                    r.get("company_resolved") or r.get("company_target", ""),
                    r.get("headline_profile") or r.get("headline", ""),
                    r.get("ai_summary", ""), r.get("mutual_connections", ""),
                    r.get("found_via", ""), r.get("profile_url", ""),
                    r.get("text_file", ""), r.get("error", "")] for r in records]

    exp_cols = ["sr_no", "name", "order", "title", "company", "dates", "duration",
                "location", "description"]
    exp_rows = [[r["sr_no"], r.get("name", ""), i, e.get("title", ""),
                 e.get("company", ""), e.get("dates", ""), e.get("duration", ""),
                 e.get("location", ""), e.get("description", "")]
                for r in records for i, e in enumerate(r.get("experience") or [], 1)]

    post_cols = ["sr_no", "name", "designation", "post_no", "date", "posted_raw",
                 "days_ago", "type", "original_author", "reactions", "comments",
                 "reposts", "text"]
    post_rows = [[r["sr_no"], r.get("name", ""), r.get("designation", ""),
                  p.get("no", 0), p.get("date", ""), p.get("posted_raw", ""),
                  p.get("days_ago", ""), p.get("type", ""), p.get("original_author", ""),
                  p.get("reactions", 0), p.get("comments", 0), p.get("reposts", 0),
                  p.get("text", "")]
                 for r in records for p in (r.get("posts") or [])]

    tables = [("final", final_cols, final_rows),
              ("people", people_cols, people_rows),
              ("experience", exp_cols, exp_rows),
              ("posts", post_cols, post_rows)]

    for name, cols, rows in tables:
        path = os.path.join(OUT_DIR, name + ".csv")
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(cols)
            w.writerows(rows)
        print("%-12s %5d rows -> %s" % (name + ".csv", len(rows), path))

    try:
        from openpyxl import Workbook
        wb = Workbook()
        wb.remove(wb.active)
        for name, cols, rows in tables:
            ws = wb.create_sheet(name.capitalize())
            ws.append(cols)
            for row in rows:
                # Excel rejects control characters and caps cells at 32767 chars
                ws.append([re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v))[:32000]
                           for v in row])
        xlsx = os.path.join(OUT_DIR, "linkedin_%s.xlsx" % company_slug(COMPANY))
        wb.save(xlsx)
        print("xlsx -> " + xlsx)
    except Exception as e:
        print("xlsx skipped (%s) - the CSVs are written" % e)

# ---------------------------------------------------------------- cli


def ask_company(given=None):
    if given:
        return given.strip()
    saved = load_state().get("company", "")
    prompt = "Which company do you want data for"
    prompt += " [%s]: " % saved if saved else ": "
    try:
        answer = input(prompt).strip()
    except EOFError:
        answer = ""
    return answer or saved


def cmd_reset_session(args):
    """Delete the saved Chrome profile.

    The cure for a sign-in that reloads forever: LinkedIn's cookies and CSRF token have
    gone out of step, and Chrome replays the stale pair on every attempt. Nothing scraped
    is touched - only the browser session.
    """
    if not os.path.isdir(PROFILE_DIR):
        print("No saved session at " + PROFILE_DIR)
        return 0
    size = sum(os.path.getsize(os.path.join(dp, f))
               for dp, _, fs in os.walk(PROFILE_DIR) for f in fs) / 1e6
    print("About to delete the saved browser session:")
    print("  %s  (%.0f MB)" % (PROFILE_DIR, size))
    print("Collected data is in linkedin_out and is not affected.")
    try:
        if input("Delete it? [y/N]: ").strip().lower() not in ("y", "yes"):
            print("Left alone.")
            return 0
    except EOFError:
        print("Left alone (no answer).")
        return 0
    shutil.rmtree(PROFILE_DIR, ignore_errors=True)
    print("Deleted. Now run:  python linkedin_win.py login")
    return 0


def cmd_redo_incomplete(args):
    """Drop records whose profile page never finished rendering, so they get refetched.

    A stalled render yields a stub page with no About section, which is indistinguishable
    from a person who simply has none. Rather than guess, those records are removed and
    the next scrape collects them again - everything else is kept.
    """
    if apply_common(args) is None:
        return 1
    records = load_records()
    if not records:
        print("Nothing collected yet in " + OUT_DIR)
        return 1

    def complete(r):
        if r.get("render_ok") is not None:
            return r["render_ok"]
        lines = [l for l in (r.get("profile_text") or "").split("\n") if l.strip()]
        return len(lines) >= MIN_PROFILE_LINES

    keep = [r for r in records if complete(r)]
    drop = len(records) - len(keep)
    if not drop:
        print("All %d records look complete." % len(records))
        return 0

    print("%d of %d records have a stub profile page." % (drop, len(records)))
    try:
        if input("Drop them so the next scrape refetches them? [y/N]: ").strip().lower() \
                not in ("y", "yes"):
            print("Left alone.")
            return 0
    except EOFError:
        print("Left alone (no answer).")
        return 0

    with open(JSONL, "w", encoding="utf-8") as f:
        for r in keep:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("Kept %d. Now run the scrape again to refill the %d." % (len(keep), drop))
    return 0


def cmd_login(args):
    start_browser(headless=False, images=True)
    print("Chrome is open. Sign in to LinkedIn in that window.")
    print("Waiting up to %d minutes ...\n" % args.wait)
    try:
        driver.get("https://www.linkedin.com/login")
    except TimeoutException:
        pass

    deadline = time.time() + args.wait * 60
    while time.time() < deadline:
        time.sleep(5)
        try:
            url = driver.current_url
        except WebDriverException:
            print("Chrome was closed before sign-in completed.")
            return 1
        if (not SIGNED_OUT_URL_RE.search(url)
                and any(m in driver.page_source for m in SIGNED_IN_MARKERS)):
            print("Signed in. Session saved to " + PROFILE_DIR)
            print("Now run:  python linkedin_win.py scrape")
            stop_browser()
            return 0
        left = int(deadline - time.time())
        state = "challenge" if "checkpoint" in url else "signed out"
        print("  still waiting (%ds left) - %s - %s" % (left, state, url[:70]))
    print("Timed out waiting for sign-in.")
    stop_browser()
    return 1


def apply_common(args):
    global POST_MONTHS, INDIA_ONLY, MIN_DELAY, MAX_DELAY
    POST_MONTHS = args.months
    INDIA_ONLY = not args.worldwide
    if getattr(args, "fast", False):
        MIN_DELAY, MAX_DELAY = FAST_DELAY
    company = ask_company(args.company)
    if not company:
        print("No company given - nothing to do.")
        return None
    set_company(company)
    return company


def cmd_scrape(args):
    if apply_common(args) is None:
        return 1
    print("\ncompany: %s | posts: last %d months | %s\n"
          % (COMPANY, POST_MONTHS, "India only" if INDIA_ONLY else "worldwide"))

    start_browser(headless=args.headless)
    if not logged_in():
        print("Not signed in. Run:  python linkedin_win.py login")
        shot("not_logged_in")
        stop_browser()
        return 1
    print("Session OK.")
    try:
        if args.skip_search and os.path.exists(INDEX_JSON):
            with open(INDEX_JSON, encoding="utf-8") as f:
                index = json.load(f)
            print("reusing the saved index of %d people" % len(index))
        else:
            index = collect_people(pages=args.pages)
        if index:
            run_profiles(index, limit=args.limit, months=POST_MONTHS)
    except Blocked as e:
        print("\nBLOCKED during search: %s" % e)
        print(BLOCK_HELP % (len(already_done()), PROFILE_DIR))
    finally:
        stop_browser()
    export(POST_MONTHS)
    return 0


def cmd_export(args):
    if apply_common(args) is None:
        return 1
    export(POST_MONTHS)
    return 0


def cmd_reparse(args):
    """Re-derive every field from the archived page text, with no network access.

    This is how a parser fix reaches data already collected: the raw text of all three
    pages is kept per person, so posts, experience and About are all rebuilt offline.
    """
    if apply_common(args) is None:
        return 1
    records = load_records()
    if not records:
        print("Nothing collected yet in " + OUT_DIR)
        return 1

    for r in records:
        r["company_target"] = COMPANY
        if r.get("experience_text"):
            r["experience_all"] = parse_experience_text(r["experience_text"])
        elif r.get("experience") and not r.get("experience_all"):
            r["experience_all"] = r["experience"]
        if r.get("activity_text"):
            r["posts_all"] = parse_posts_text(r["activity_text"], r.get("name", ""))
        if r.get("profile_text"):
            r["about"] = scrape_about_text(r["profile_text"]) or r.get("about", "")
        derive(r, POST_MONTHS)

    with open(JSONL, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("reparsed %d profiles" % len(records))
    export(POST_MONTHS)
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--company", default=None,
                       help="company name (you are asked for it if omitted)")
        p.add_argument("--months", type=int, default=POST_MONTHS,
                       help="post window in months (default %d)" % POST_MONTHS)
        p.add_argument("--worldwide", action="store_true", help="do not restrict to India")
        p.add_argument("--fast", action="store_true",
                       help="shorter delays; raises the chance of being rate-limited")
        return p

    p = common(sub.add_parser("redo-incomplete",
                              help="refetch profiles whose page never fully rendered"))
    p.set_defaults(func=cmd_redo_incomplete)

    p = sub.add_parser("reset-session",
                       help="delete the saved Chrome session (fixes a sign-in loop)")
    p.set_defaults(func=cmd_reset_session)

    p = sub.add_parser("login", help="open Chrome and wait for you to sign in")
    p.add_argument("--wait", type=int, default=10, help="minutes to wait (default 10)")
    p.set_defaults(func=cmd_login)

    p = common(sub.add_parser("scrape", help="collect search results, then each profile"))
    p.add_argument("--pages", type=int, default=None, help="search pages per role term")
    p.add_argument("--limit", type=int, default=None, help="max profiles this run")
    p.add_argument("--headless", action="store_true", help="hide the browser window")
    p.add_argument("--skip-search", action="store_true",
                   help="reuse the saved index instead of searching again")
    p.set_defaults(func=cmd_scrape)

    p = common(sub.add_parser("export", help="write csv/json from collected data"))
    p.set_defaults(func=cmd_export)

    p = common(sub.add_parser("reparse", help="rebuild fields from archived text, then export"))
    p.set_defaults(func=cmd_reparse)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
