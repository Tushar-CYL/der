# LinkedIn scraper - any company, posts from the last N months

Asks which company you want, searches LinkedIn People for managers / senior managers /
directors / partners, then opens each profile and collects:

- name, designation **at that company**, years of experience **at that company**, location
- the About section (the "description")
- every post and repost from the **last 3 months**, full text plus engagement counts

Built and debugged on an 8 GB laptop where long runs kept being killed for memory. On a
16 GB+ machine it should run straight through.

---

## 1. Install (5 minutes)

**Google Chrome** (the normal browser) and **Python 3.9+**, then:

```
pip install selenium beautifulsoup4 lxml openpyxl
```

Or double-click `install.bat`. That is the whole list - Selenium Manager downloads the
matching chromedriver itself on first run. `pandas` is deliberately not used.

## 2. Run

```
python linkedin_win.py login
```

Chrome opens on the LinkedIn login page. Sign in yourself. Images are enabled during
login specifically so a CAPTCHA is visible; they are blocked during scraping for speed.
The session saves to `.chrome_linkedin_profile\` beside the script, so this is one-time
per machine. `--wait 20` gives you longer.

```
python linkedin_win.py scrape
```

Asks **"Which company do you want data for:"**. Type `Tesco`, `Diageo`, `Takeda`,
anything. Then it searches, then scrapes each person. It resumes automatically and saves
after **every single person**.

```
python linkedin_win.py export
```

Rebuilds the output files from whatever has been collected. Safe to run at any time.

### Options

```
python linkedin_win.py scrape --company Tesco      # skip the question
python linkedin_win.py scrape --months 6           # 6 months of posts instead of 3
python linkedin_win.py scrape --limit 50           # only 50 people this run
python linkedin_win.py scrape --skip-search        # reuse the saved index, go straight to profiles
python linkedin_win.py scrape --worldwide          # global (the default restricts to India)
python linkedin_win.py scrape --pages 10           # search pages per role term
python linkedin_win.py scrape --headless           # no visible window
python linkedin_win.py scrape --fast               # shorter delays - RAISES the block risk
```

### The other commands

```
python linkedin_win.py reparse            # rebuild every field offline, no LinkedIn calls
python linkedin_win.py redo-incomplete    # refetch profiles whose page never fully rendered
python linkedin_win.py reset-session      # delete the saved login (fixes a sign-in loop)
```

## 3. What is already in this zip

`linkedin_out\tesco\` holds a partial Tesco run:

- **370 people indexed** from 10 search pages x 4 role terms (`people_index.json`)
- **25 people fully scraped**, 77 roles, 52 posts
- 345 still to do - run the scrape again and it continues from there

To finish it on the new machine:

```
python linkedin_win.py login
python linkedin_win.py scrape --company Tesco --worldwide --skip-search
```

`--skip-search` reuses the saved index, so no search pages are fetched twice.

## 4. Output files

Per company, in `linkedin_out\<company>\`:

| File | What |
|---|---|
| **`final.json`** | everything, structured - posts stay as real objects |
| **`final.csv`** | one row per person: `sr_no, name, designation, yoe_at_company, yoe_years, location, description, n_posts, posts, ...` with every post numbered inside the `posts` cell |
| `people.csv` | the same people without the posts blob |
| `experience.csv` | one row per role **at that company only** |
| `posts.csv` | one row per post, with date, type, reactions, comments, reposts |
| `linkedin_<company>.xlsx` | all four as one workbook |
| `profiles.jsonl` | raw record per person - **the resume file** |
| `people_index.json` | everyone found by search |
| `text\*.txt` | archived page text, so `reparse` can rebuild offline |

The `posts` cell in `final.csv` reads like this:

```
1. [2026-10-24] reactions=1067 comments=62 reposts=152
<full post text, every paragraph>

2. [2026-10-22] (repost of Saurabh Dixit) reactions=150 comments=14 reposts=6
<full post text>
```

## 5. Pacing, and why it is slow on purpose

Roughly **80 seconds per person**: 6-15s between page loads, a ~4 minute break every 12
people, a ~15 minute break every 45. So ~370 people is about 8 hours.

This is not caution for its own sake. Running faster got the account bounced to a login
after about 20 profiles. The activity feed is the expensive page: every scroll fires its
own API calls, so posts cost many times more requests than profile pages do.

If LinkedIn does push back, the run **stops immediately** and prints what to do. An
earlier version carried on, which was worse than useless - it wrote a run of empty
records, marked those people as done so a resume skipped them, and kept hammering an
endpoint that had already said no.

**Scraping breaches LinkedIn's User Agreement.** Enforcement escalates from a soft limit,
to a temporary restriction, to ID verification, to a permanent ban. A few hundred
profiles spread over days looks far more human than thousands in one sitting. It is your
call, but it is a real risk to a real account.

## 6. Known-good, and known limits

**Working, verified against live pages:**

- search and indexing (370 found for Tesco from 10 pages)
- designation and tenure at the target company only, other employers excluded
- the About / description text
- post text in full, with reactions, comments and repost counts
- resume after any interruption

**Limits worth knowing:**

- A **brand-new LinkedIn account returns `LinkedIn Member` for every result** and
  collects nothing. Names are only visible to an account with a real network. No code
  change fixes this - it is what LinkedIn serves that account.
- A profile whose page stalls mid-render is saved as a stub with no About section. It is
  flagged in the log, and `redo-incomplete` drops those records so the next scrape
  refetches them. This was common on the 8 GB machine, rare otherwise.
- `--worldwide` is needed for global results; the default restricts to India.

## 7. How the tricky parts work

**No CSS selectors or XPaths are used for content.** LinkedIn ships hashed class names
(`l4jkxn`, `l4jlyw`) regenerated on every deploy, so anything keyed to them breaks within
days. The parsers use visible text and stable landmarks instead: date lines for jobs, the
`Feed post` heading for posts, the `About` heading for the description, and "an `/in/`
link with no `/in/` link above it" for search result cards.

**Only the target company's experience is reported.** Rows match on normalised company
tokens, so `Tesco`, `Tesco PLC` and `Tesco Bengaluru` all count, while `Tescore
Analytics` does not. Overlapping roles are merged, so six promotions at one employer give
one correct total rather than six added together.

**Company groups close on their own total.** LinkedIn groups several roles under an
employer header carrying a total like `5 yrs 7 mos`, and nothing in the page marks where
that group ends. The parser adds up each role it assigns and closes the group once the
header's total is used up. Without this, the next employer's roles are credited to the
previous one - that bug turned a 10-year tenure into 18 years and labelled a Dell job as
Tesco.

**"...more" toggles inside links are never clicked.** On a profile page, 10 of 13 such
toggles sit inside `<a>` tags belonging to activity preview cards. Clicking one navigates
to that post, and the scraper then captured *that page* as the profile - which is why
names came out as `Feed post` and locations as `AI Engineer`. Blocking it with
`preventDefault` does not work, because LinkedIn's router navigates programmatically
rather than through the link's default action. The activity page is unaffected: none of
its toggles are inside links, so full post text still comes through.

**Engagement counts are split across lines.** LinkedIn writes `724` and `reactions` as
two separate lines, and social proof as `Astik Raj` / `and` / `149` / `others reacted`
(which means 150). The parser reads both forms; a single-line regex silently returned
zero for everything.

**Profile text is read only once the page has painted**, and the pre-click capture is kept
as a fallback behind a URL check, so a profile can never be recorded as some other page's
content.
