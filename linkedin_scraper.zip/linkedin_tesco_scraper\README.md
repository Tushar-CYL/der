# LinkedIn scraper - five fields per person, per company

Asks which company you want, searches LinkedIn People for managers / senior managers /
directors / partners, then opens each profile and collects exactly five things:

1. **name**
2. **location**
3. **title** at that company
4. **experience** at that company - total tenure, and each role
5. **About** - the profile description

Nothing else. **Posts are gone**: not collected, not parsed, not in the output. The
activity feed cost thirty-odd requests per person and was what triggered rate limiting,
so the feed scraper and its parser have been deleted from the code, not just switched
off.

---

## 1. Install (5 minutes)

**Google Chrome** (the normal browser) and **Python 3.9+**, then:

```
pip install selenium beautifulsoup4 lxml
```

Or double-click `install.bat`. That is the whole list - Selenium Manager downloads the
matching chromedriver itself on first run.

## 2. Run

```
python linkedin_win.py login
```

Chrome opens on the LinkedIn login page. Sign in yourself. Images are enabled during
login specifically so a CAPTCHA is visible; they are blocked during scraping for speed.
The session saves to `.chrome_linkedin_profile\` beside the script, so this is one-time
per machine. `--wait 20` gives you longer.

```
python linkedin_win.py scrape --company Takeda --worldwide
```

Searches, indexes, then opens each profile. It resumes automatically and saves after
**every single person**, so an interruption costs you nothing.

```
python linkedin_win.py export
```

Rebuilds the two output files from whatever has been collected. Safe to run any time, and
it never touches LinkedIn.

### All the options

```
--company NAME     skip the question
--worldwide        global results (the default restricts to India)
--skip-search      reuse the saved index, go straight to profiles
--limit 10         only this many people this run - good for a trial
--pages 5          search pages per role term (default 10)
--headless         no visible browser window
--fast             shorter delays - RAISES the chance of being rate-limited
```

### The other commands

```
python linkedin_win.py reparse            # rebuild both files offline, no LinkedIn calls
python linkedin_win.py redo-incomplete    # refetch profiles whose page never rendered
python linkedin_win.py reset-session      # delete the saved login (fixes a sign-in loop)
```

## 3. Output: two files

Per company, in `linkedin_out\<company>\`:

| File | What |
|---|---|
| **`people.json`** | one object per person, full untrimmed text, roles as real objects |
| **`final.csv`** | one row per person, 10 columns, **one record per line** |

`final.csv` columns:

```
sr_no, name, location, title, yoe_at_company, yoe_years, n_roles, profile_url,
about, experience
```

Rows are ordered by longest tenure at the company first.

### How the CSV stays aligned

**Every row is exactly one line in the file.** Every cell is flattened - no newlines, no
tabs, no control characters, repeated spaces collapsed - and every field is quoted, so a
comma or a quote inside a description cannot shift the columns. A cell holding a real
newline splits one record over several physical lines, which is what makes a CSV look
broken anywhere but a spreadsheet.

The role list is numbered inline, items separated by `||`:

```
1. Buying Manager | Tesco | Sep 2023 - Present · 3 yrs 2 mos | Welwyn Garden City  ||  2. Category Manager | Tesco | Jan 2019 - Sep 2023 · 4 yrs 9 mos
```

Cells are capped at 32,000 characters because Excel rejects anything longer; a capped
cell says so and points at `people.json`. With posts gone the longest cell in the Tesco
data is 4,370 characters, so this no longer comes up.

### Working files in the same folder

Not output. Leave them alone:

| File | Why it is there |
|---|---|
| `profiles.jsonl` | the raw record per person - **the resume file**; delete it and the scrape starts over |
| `people_index.json` | everyone found by search, so `--skip-search` can reuse it |
| `text\*.txt` | a verbatim copy of each page's visible text, so `reparse` can rebuild every field offline |
| `state.json` | the last company name, for the prompt's default |

The page archive in `text\` is a copy of the page as it was, so for people who post it
still contains the post previews that LinkedIn shows on a profile. Nothing reads them -
no output field can contain post text, and that is checked: zero of the 25 Tesco rows
have any post-flavoured text in `name`, `location`, `title`, `about` or `experience`.

## 4. About the description

This is the field most likely to look "missing" when it is not. **Most LinkedIn profiles
genuinely have no About section.** Of the 25 Tesco people collected so far, 5 have one.
Their pages go straight from the top card to Activity - there is no About heading in the
page at all, so there is nothing to parse.

The run and the export both report the count:

```
[ 12/345] Keshav Akasam          roles=1  5 yrs 2 mos  desc=NONE    27s eta 2h34m
...
             68 of 345 have a description
```

`desc=NONE` means that person left it blank. Not a scraper failure, and re-running will
not change it.

What the scraper does do, so a description that *is* there always gets captured: expands
the About section's own "...more" directly, retries, re-reads after each attempt, falls
back to reading it out of the markup via the `id="about"` anchor, and accepts a one-line
About rather than requiring a long paragraph.

## 5. Speed

Roughly **30 seconds per person**, so about 3 hours for 370. Two page loads each - the
profile and the experience page - with 3-7.5s between them, a 2 minute pause every 30
people and a 7 minute break every 100.

Where the time went, and what was cut:

- **The activity feed is gone.** It was thirty-odd requests per person on its own.
- **Document transfers per person: 5, down from 13.** Reading `driver.page_source`
  serialises the whole DOM - a megabyte or more on LinkedIn - and sends it over the
  WebDriver connection. The old render-wait did that up to seven times per profile just
  to find out whether the page had finished painting; that question is now asked inside
  the browser (does `main` have an `h1` and a section anchor?) and costs nothing.
  `goto()` also returned a page source that no caller ever used.
- **Clicks on the profile page: 0 or 1, down from 13.** Only the About toggle is clicked
  now. The page-wide expander existed to open post previews, and those were exactly the
  toggles that navigated away and wrecked the capture.
- **One scroll on the profile page instead of three.** Everything wanted from it is at
  the top; the render-wait scrolls again only if the page has not finished.

`--fast` cuts the delays further. It raises the risk; it is there for a short run on an
account you do not mind losing.

If LinkedIn does push back, the run **stops immediately** and prints what to do. An
earlier version carried on, which was worse than useless - it wrote a run of empty
records, marked those people as done so a resume skipped them, and kept hammering an
endpoint that had already said no.

**Scraping breaches LinkedIn's User Agreement.** Enforcement escalates from a soft limit,
to a temporary restriction, to ID verification, to a permanent ban. A few hundred
profiles spread over days looks far more human than thousands in one sitting, and one
company per sitting is safer than eleven in a day. It is your call, but it is a real risk
to a real account.

## 6. Doing several companies

Each company gets its own folder, so nothing overlaps and each resumes separately:

```
python linkedin_win.py scrape --company "Takeda" --worldwide
python linkedin_win.py scrape --company "Diageo" --worldwide
python linkedin_win.py scrape --company "Kimberly-Clark" --worldwide
```

**Type the name the way LinkedIn prints it in the experience rows**, because that is what
tenure matching compares against. It normalises and matches on whole tokens, so `BP` also
catches `BP plc` and `Tesco` catches `Tesco Bengaluru` - but `BCG` will **not** match a
profile that says `Boston Consulting Group`.

A mismatch is visible rather than silent: that person gets `n_roles = 0`, an empty
`experience` cell, and a `title` taken from their headline instead of a parsed role
(`title_source: "headline"` in `people.json`).

## 7. Known-good, and known limits

**Working, verified against live pages:**

- search and indexing (370 found for Tesco from 10 pages)
- title and tenure at the target company only, other employers excluded
- the About text, where the person has one
- resume after any interruption

**Limits worth knowing:**

- A **brand-new LinkedIn account returns `LinkedIn Member` for every result** and
  collects nothing. Names are only visible to an account with a real network. No code
  change fixes this - it is what LinkedIn serves that account.
- A profile whose page stalls mid-render is saved as a stub with no About section. It is
  flagged in the log, and `redo-incomplete` drops those records so the next scrape
  refetches them.
- `--worldwide` is needed for global results; the default restricts to India.

## 8. How the tricky parts work

**No CSS selectors or XPaths are used for content.** LinkedIn ships hashed class names
(`l4jkxn`, `l4jlyw`) regenerated on every deploy, so anything keyed to them breaks within
days. The parsers use visible text and stable landmarks instead: date lines for jobs, the
`About` heading for the description, and "an `/in/` link with no `/in/` link above it" for
search result cards. The one id that is safe to use is each section's anchor div
(`id="about"`, `id="experience"`), which exists for in-page links and survives deploys.

**Only the target company's experience is reported.** Rows match on normalised company
tokens, so `Tesco`, `Tesco PLC` and `Tesco Bengaluru` all count, while `Tescore
Analytics` does not. Overlapping roles are merged, so six promotions at one employer give
one correct total rather than six added together.

**Company groups close on their own total.** LinkedIn groups several roles under an
employer header carrying a total like `5 yrs 7 mos`, and nothing in the page marks where
that group ends. The parser adds up each role it assigns and closes the group once the
header's total is used up. Without this, the next employer's roles are credited to the
previous one - that bug turned a 10-year tenure into 18 years and labelled a Dell job as
Tesco.

**The About expander is scoped to the About section.** On a profile page, 10 of 13
"...more" toggles sat inside `<a>` tags belonging to activity preview cards. Clicking one
navigated to that post, and the scraper then captured *that page* as the profile - which
is why names once came out as `Feed post` and locations as `AI Engineer`. Blocking it
with `preventDefault` does not work, because LinkedIn's router navigates programmatically
rather than through the link's default action. Nothing inside the About section is a link,
so scoping the expander there removes the problem entirely.

**Profile text is read only once the page has painted**, and if an expand click does
somehow navigate away, the pre-click capture is used instead, behind a URL check. A
profile can never be recorded as some other page's content.
