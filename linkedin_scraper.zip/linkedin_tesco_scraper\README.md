# LinkedIn scraper - any company

Asks which company you want, searches LinkedIn People for managers / senior managers /
directors / partners, then opens each profile and collects:

- name, designation **at that company**, years of experience **at that company**, location
- the **About section** (the "description") - the field this is tuned around
- optionally, with `--posts`, every post and repost from the last N months

**Posts are off by default.** The activity feed is the expensive page - every scroll
fires its own API calls - and it is what got the account bounced to a login after about
20 profiles. Leaving it out drops a person from thirty-odd requests to two, which is why
the pace can safely come up: roughly **35 seconds per person instead of 80**.

Built and debugged on an 8 GB laptop where long runs kept being killed for memory. On a
16 GB+ machine it should run straight through.

---

## 1. Install (5 minutes)

**Google Chrome** (the normal browser) and **Python 3.9+**, then:

```
pip install selenium beautifulsoup4 lxml
```

Or double-click `install.bat`. That is the whole list - Selenium Manager downloads the
matching chromedriver itself on first run. `pandas` is deliberately not used.

## 2. Run

```
python linkedin_win.py login
```

Chrome opens on the LinkedIn login page. Sign in yourself. Images are enabled during
login specifically so a CAPTCHA is visible; they are blocked during scraping for speed.
The session saves to `.chrome_linkedin_profile\` beside the script, so this is one-time
per machine. `--wait 20` gives you longer.

```
python linkedin_win.py scrape
```

Asks **"Which company do you want data for:"**. Type `Tesco`, `Diageo`, `Takeda`,
anything. Then it searches, then scrapes each person. It resumes automatically and saves
after **every single person**.

```
python linkedin_win.py export
```

Rebuilds the output files from whatever has been collected. Safe to run at any time.

### Options

```
python linkedin_win.py scrape --company Tesco      # skip the question
python linkedin_win.py scrape --worldwide          # global (the default restricts to India)
python linkedin_win.py scrape --skip-search        # reuse the saved index, go straight to profiles
python linkedin_win.py scrape --limit 50           # only 50 people this run
python linkedin_win.py scrape --pages 10           # search pages per role term
python linkedin_win.py scrape --headless           # no visible window
python linkedin_win.py scrape --posts              # also collect posts (slow, riskier)
python linkedin_win.py scrape --posts --months 6   # 6 months of posts instead of 3
python linkedin_win.py scrape --fast               # shorter delays - RAISES the block risk
```

### The other commands

```
python linkedin_win.py reparse            # rebuild every field offline, no LinkedIn calls
python linkedin_win.py redo-incomplete    # refetch profiles whose page never fully rendered
python linkedin_win.py reset-session      # delete the saved login (fixes a sign-in loop)
```

## 3. What is already in this zip

`linkedin_out\tesco\` holds a partial Tesco run:

- **370 people indexed** from 10 search pages x 4 role terms (`people_index.json`)
- **25 people fully scraped**, 77 roles, and 52 posts from when posts were still on
- 345 still to do - run the scrape again and it continues from there

To finish it on the new machine:

```
python linkedin_win.py login
python linkedin_win.py scrape --company Tesco --worldwide --skip-search
```

`--skip-search` reuses the saved index, so no search pages are fetched twice. Those 345
will be collected without posts, which is the point - the 52 posts already in there stay
where they are and still appear in the output.

## 4. Output: two files

Each scrape writes exactly **two** output files into `linkedin_out\<company>\`:

| File | What |
|---|---|
| **`people.json`** | **everything.** One object per person, with the full description, the roles nested as real objects, and the posts nested as real objects. Nothing is shortened. |
| **`final.csv`** | **one row per person, every field in it.** One record per line, so it opens cleanly in Excel, Sheets, pandas or a text editor. |

`final.csv` columns, in this order:

```
sr_no, name, designation, yoe_at_company, yoe_years, location, description,
company, headline, n_roles_at_company, n_posts, designation_source,
mutual_connections, found_via, profile_url, slug, text_file, error,
experience, posts
```

The short columns come first so the sheet reads across without scrolling, and the two
long text cells (`experience`, `posts`) go last, where a wide column does not push
everything else off the screen.

### How the CSV stays aligned

**Every row is exactly one line in the file.** Every cell is flattened: no newlines, no
tabs, no stray control characters, and repeated spaces collapsed. A cell that contains a
real newline splits one record over several physical lines, which is what makes a CSV
look broken in anything that is not a spreadsheet.

So the lists are numbered inline, items separated by `||`:

```
1. Senior Software Engineering Manager | Tesco | Sep 2021 - Present · 5 yrs 2 mos | Bangalore  ||  2. Software Engineering Manager | Tesco | Aug 2018 - Sep 2021 · 3 yrs 2 mos
```

```
1. [2026-10-24] reactions=1067 comments=62 reposts=152 -- <post text>  ||  2. [2026-10-22] (repost of Saurabh Dixit) reactions=150 comments=14 reposts=6 -- <post text>
```

**Cells are capped at 32,000 characters**, because Excel rejects a cell over 32,767
outright - one person in the current Tesco data has 34,005 characters of posts, which
would have broken the file. A capped cell ends with
`...[truncated - full text in people.json]`. Only the `posts` cell ever gets near this;
`description` and `experience` never have.

Every field is quoted, so a comma or a quotation mark inside a description cannot shift
the columns.

`n_posts` and `posts` appear **only when posts were actually collected** - with posts
off they are left out rather than filled with zeros (18 columns instead of 20), and rows
are ordered by longest tenure at the company first.

### The other files in the folder

These are working files, not output. Leave them alone:

| File | Why it is there |
|---|---|
| `profiles.jsonl` | the raw record per person - **this is the resume file**; delete it and the scrape starts over |
| `people_index.json` | everyone found by search, so `--skip-search` can reuse it |
| `text\*.txt` | archived page text, so `reparse` can rebuild every field offline |
| `state.json` | the last company name, used for the prompt's default |

Earlier versions also wrote `final.json`, `experience.json`, `posts.json`,
`people.csv`, `experience.csv`, `posts.csv` and an `.xlsx`. They are gone, and `export`
deletes any left over from an older run - a stale copy sitting in the folder looking
current is worse than no copy at all.

## 5. About the description

This is the field most likely to look "missing" when it is not. **Most LinkedIn profiles
genuinely have no About section.** Of the 25 Tesco people collected so far, 5 have one.
Their pages go straight from the top card to Activity - there is no About heading in the
page at all, so there is nothing to parse.

So the run and the export both report the count:

```
[ 12/345] Keshav Akasam          roles=1  5 yrs 2 mos  desc=NONE   34s eta 3h11m
...
             68 of 345 have a description
```

`desc=NONE` means that person left it blank. It is not a scraper failure, and
re-running will not change it.

What the scraper does do, to make sure a description that *is* there gets captured:
expands the About section's own "...more" directly, retries, re-reads the page after
each attempt, falls back to reading it out of the markup, and accepts a one-line About
rather than requiring a long paragraph.

## 6. Pacing

Roughly **35 seconds per person** without posts: 4-10s between page loads, a ~2.5 minute
pause every 25 people, a ~10 minute break every 80. So 345 people is about 3.5 hours.

With `--posts` it slows to ~80 seconds per person and stretches the same job to ~8 hours,
because the activity feed is fetched and scrolled per person.

If LinkedIn does push back, the run **stops immediately** and prints what to do. An
earlier version carried on, which was worse than useless - it wrote a run of empty
records, marked those people as done so a resume skipped them, and kept hammering an
endpoint that had already said no.

**Scraping breaches LinkedIn's User Agreement.** Enforcement escalates from a soft limit,
to a temporary restriction, to ID verification, to a permanent ban. A few hundred
profiles spread over days looks far more human than thousands in one sitting. It is your
call, but it is a real risk to a real account.

## 7. Known-good, and known limits

**Working, verified against live pages:**

- search and indexing (370 found for Tesco from 10 pages)
- designation and tenure at the target company only, other employers excluded
- the About / description text, where the person has one
- resume after any interruption
- post text in full with reactions, comments and repost counts, under `--posts`

**Limits worth knowing:**

- A **brand-new LinkedIn account returns `LinkedIn Member` for every result** and
  collects nothing. Names are only visible to an account with a real network. No code
  change fixes this - it is what LinkedIn serves that account.
- A profile whose page stalls mid-render is saved as a stub with no About section. It is
  flagged in the log, and `redo-incomplete` drops those records so the next scrape
  refetches them. This was common on the 8 GB machine, rare otherwise.
- `--worldwide` is needed for global results; the default restricts to India.

## 8. How the tricky parts work

**No CSS selectors or XPaths are used for content.** LinkedIn ships hashed class names
(`l4jkxn`, `l4jlyw`) regenerated on every deploy, so anything keyed to them breaks within
days. The parsers use visible text and stable landmarks instead: date lines for jobs, the
`About` heading for the description, the `Feed post` heading for posts, and "an `/in/`
link with no `/in/` link above it" for search result cards. The one id that is safe to
use is each section's anchor div (`id="about"`), which exists for in-page links and
survives deploys.

**Only the target company's experience is reported.** Rows match on normalised company
tokens, so `Tesco`, `Tesco PLC` and `Tesco Bengaluru` all count, while `Tescore
Analytics` does not. Overlapping roles are merged, so six promotions at one employer give
one correct total rather than six added together.

**Company groups close on their own total.** LinkedIn groups several roles under an
employer header carrying a total like `5 yrs 7 mos`, and nothing in the page marks where
that group ends. The parser adds up each role it assigns and closes the group once the
header's total is used up. Without this, the next employer's roles are credited to the
previous one - that bug turned a 10-year tenure into 18 years and labelled a Dell job as
Tesco.

**"...more" toggles inside links are never clicked.** On a profile page, 10 of 13 such
toggles sit inside `<a>` tags belonging to activity preview cards. Clicking one navigates
to that post, and the scraper then captured *that page* as the profile - which is why
names came out as `Feed post` and locations as `AI Engineer`. Blocking it with
`preventDefault` does not work, because LinkedIn's router navigates programmatically
rather than through the link's default action. The About expander is scoped to the About
section alone, where nothing is a link, so it can click freely.

**Engagement counts are split across lines.** LinkedIn writes `724` and `reactions` as
two separate lines, and social proof as `Astik Raj` / `and` / `149` / `others reacted`
(which means 150). The parser reads both forms; a single-line regex silently returned
zero for everything.

**Profile text is read only once the page has painted**, and the pre-click capture is kept
as a fallback behind a URL check, so a profile can never be recorded as some other page's
content.
